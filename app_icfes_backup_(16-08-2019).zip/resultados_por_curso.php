<?php
require("conexion.php");
session_start();

$id_profesor=$_SESSION['id_profesor'];
$filtrar_curso=$_POST['filtrar_curso'];

// $id_profesor="2";

// $filtrar_curso="4";


$query="SELECT * 
			FROM curso
			 INNER JOIN usuario 
				on curso.id_curso=usuario.fk_curso 
			INNER JOIN quiz 
				on usuario.id_usuario=quiz.fk_usuario 
	WHERE curso.id_curso='$filtrar_curso' 
	AND curso.fk_profesor='$id_profesor' ORDER BY quiz.resultado DESC";

$resultado=mysqli_query($conn,$query);
$consulta=array();
// $rowcount=mysqli_num_rows($resultado);
while ($row=mysqli_fetch_array($resultado)) {
	$consulta[]=array(
		'nombre'=>$row['nombre'],
		'apellido'=>$row['apellido'],
		'nombre_curso'=>$row['nombre_curso'],
		'fecha'=>$row['fecha'],
		'tiempo'=>$row['tiempo'],
		'resultado'=>$row['resultado'],
		'resultado_icfes'=>$row['resultado_icfes']
	);
}

echo json_encode($consulta)

?>
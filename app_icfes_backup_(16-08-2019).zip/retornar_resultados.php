<?php
require("conexion.php");
   session_start();
 
 // if(isset($_SESSION["login_user"])){
 //    header("Location: prueba.php");
 //  } 


  $id_actual_user=$_SESSION['id_login_user'];

//  echo $id_actual_user; 

// $result=mysqli_query($conn,"SELECT * FROM quiz WHERE fk_usuario='$id_actual_user'");
// $count=mysqli_num_rows($result);
// $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
// // If result matched $username and $password, table row  must be 1 row
// if($count==1)
// {
// echo $row['fecha']; 
// echo $row['resultado']; 

// // echo $row['nombre'];
// }




$ttenQ="SELECT * FROM quiz WHERE fk_usuario='$id_actual_user'";
$resultado = mysqli_query($conn,$ttenQ);

$consulta = array();

$rowcount=mysqli_num_rows($resultado);
// printf("Result set has %d rows.\n",$rowcount);
while ($row=mysqli_fetch_array($resultado)) {

    $consulta[]=array(
    	// 'estado' => 'ok',
    	'fecha'=> $row["fecha"],
    	'resultado'=>$row["resultado"],
    	'resultado_icfes'=>$row["resultado_icfes"]
    );
}

echo json_encode($consulta);
// echo json_encode($consulta, JSON_FORCE_OBJECT);






  ?>
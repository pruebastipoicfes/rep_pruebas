<?php




   $servername = "localhost";
    $username = "u858704186_root";
    $password = "samsung2015oks";
    $dbname = "u858704186_bd";
   // $servername = "localhost";
   //  $username = "u858704186_root";
   //  $password = "";
   //  $dbname = "u858704186_bd";

    $conn = new mysqli($servername, $username, $password, $dbname);
      if($conn->connect_error){
        die("Conexión fallida: ".$conn->connect_error);
      }
      else
      	{
          // echo "si conecto";
        }

          $conn->set_charset("utf8");

?>
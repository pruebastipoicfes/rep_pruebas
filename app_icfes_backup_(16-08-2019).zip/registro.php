
  <?php  



require("conexion.php");
  session_start();


date_default_timezone_set('America/Bogota');
$dates = date('Y-m-d H:i:s');
// $fecha_actual=substr($dates,0,10);
// $hora_actual=substr($dates,11);
// echo $hora;

  $id_actual =$_SESSION['id_login_user'];

//   $colegio = $_POST['colegio'];
//   $curso = $_POST['curso'];
//   $fecha = $_POST['fecha'];
//   $profesor = $_POST['profesor'];
 


// ini_set('date.timezone','America/Bogota'); 
// $hoy = date("H:i:s");
// echo $hoy;
// $fecha_hora=$fecha.' '.$hoy;

$_SESSION['fecha_registro']=$dates;

// REGISTER data into database
    $sql = "INSERT INTO quiz(fk_usuario, fecha) VALUES ('$id_actual','$dates')";
    // $query = mysqli_query($conn,$sql);


if (mysqli_query($conn, $sql)) {
     $messages= "New record created successfully";
}

   echo $messages;
  ?>
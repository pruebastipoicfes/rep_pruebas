<?php
require("conexion.php");
   session_start();
  // if(isset($_SESSION["id_login_user"])){
  //   header("Location: resultados.php");
  // } 

$resultado_consulta='';
if(isset($_POST['correo']) && isset($_POST['contrasena']))
{

	$username=mysqli_real_escape_string($conn,$_POST['correo']); 
	$password=mysqli_real_escape_string($conn,$_POST['contrasena']); 

// $username='giovanny-296@hotmail.com';
// $password='123'; 
// $username='fs@hotmail.com';
// $password='123'; 

$result=mysqli_query($conn,"SELECT * FROM usuario INNER JOIN curso on usuario.fk_curso=curso.id_curso WHERE usuario.email='$username' and usuario.contrasena='$password'");
$count=mysqli_num_rows($result);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);

if($count==1)
{
$_SESSION['id_login_user']=$row['id_usuario']; //Storing user session value.
$id_usu=$_SESSION['id_login_user'];
$_SESSION['login_user']=$row['nombre']; //Storing user session value.
$_SESSION['login_curso']=$row['nombre_curso'];
$_SESSION['login_user_surname']=$row['apellido'];
$_SESSION['contrasena']=$row['contrasena'];

// echo $_SESSION['id_login_user'];

$consulta_2= mysqli_query($conn,"SELECT fk_usuario FROM quiz WHERE quiz.fk_usuario='$id_usu' ");

$count_2=mysqli_num_rows($consulta_2);

if($count_2==0) // no ha presentado quiz
{
	$resultado_consulta= $row['nombre_curso'];
}
else
{
	$resultado_consulta="no";
}


}
else
{
	$resultado_consulta="data_wrong";
}

}
else
{
	$resultado_consulta= "data_wrong";
}
echo $resultado_consulta;

  ?>






















  
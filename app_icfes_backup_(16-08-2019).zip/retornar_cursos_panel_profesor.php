<?php
require("conexion.php");
 session_start();
 
$id_profesor=$_SESSION['id_profesor'];
 // $id_profesor="1";
// $ttenQ="SELECT * FROM curso ";

$ttenQ="SELECT curso.id_curso,curso.fk_profesor,curso.nombre_curso,profesor.id_profesor FROM curso INNER JOIN profesor on curso.fk_profesor=profesor.id_profesor WHERE curso.fk_profesor='$id_profesor'";
$resultado = mysqli_query($conn,$ttenQ);

$consulta = array();

$rowcount=mysqli_num_rows($resultado);

while ($row=mysqli_fetch_array($resultado)) {

    $consulta[]=array(
    	'fk_profesor'=> $row["fk_profesor"],
    	'id_curso'=>$row["id_curso"],
    	'id_profesor'=>$row["id_profesor"],
    	'nombre_curso'=>$row["nombre_curso"]

    );
}

echo json_encode($consulta);

  ?>
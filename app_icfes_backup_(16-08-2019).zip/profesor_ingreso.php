<!DOCTYPE html>
<html>
  <head>
    <title>Ingresar</title>
    <meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
    <link type='text/css' rel='stylesheet' href='css/stylesheet.css'/>



   <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<!-- jQuery library -->




 <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />


<!-- ggggggggggggggggg -->
  <link rel="stylesheet" type="text/css" href="css/select2.css">

  <script src="jquery-3.1.1.min.js"></script>


<style>
  ul.ui-autocomplete {
    /*z-index: 1100;*/
        z-index: 1100;
}
</style>

  </head>
  <body>
<div class="ind_div_encabezado">

        <img style="width: 100%;" src="https://www.pruebastipoicfes.com/img/encabezado_2.png" alt="">
        
</div>
     <a style="margin-left: 8%;" href="index.php" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-arrow-left"></span> Atrás
        </a>
<div class="ind_div_general">


        <!-- PARA PROFESORES -->
          <div id="box"  style=" margin-left: 29%;"  class="f_ingresar">
      <div class="titulo_1"><h4>Ingresar profesor<h4></div>
         <div id="statusMsg_profesor"> </div>
      <form class="form-horizontal" id="ingresar_profesor" action="" method="post"> <div id="error_profesor"></div> 
        <div class="form-group">
          <label for="ing_correo_profesor" class="col-sm-2 control-label">Correo</label>
          <div class="col-sm-10">
            <input type="correo" class="form-control" name="ing_correo_profesor" id="ing_correo_profesor" placeholder="Correo" value="@gmail.com" required>
          </div>
        </div>
        <div class="form-group">
          <label for="ing_password_profesor" class="col-sm-2 control-label">Contraseña</label>
          <div class="col-sm-10">
            <input type="password" class="form-control" name="ing_password_profesor" id="ing_password_profesor" placeholder="Contraseña" value="" required>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
            <a id="btn_ingresar_profesor"  style="float: right; margin-left: 40%; margin-bottom: 3%;" class="btn btn-primary btn-sm">Ingresar</a>
           
          </div>

        </div>
      </form>
      
       <div class="form-group" id="btn_registro_datos_profesor">
              ¿Aún no tienes cuenta ?<a style="float: right;" class="btn btn-success btn-sm " data-toggle="modal" data-target="#modalForm_profesor">Registrarse</a>
            </div>





    </div>
    <div>

</div>
    <div style="margin-top: 2%; float: left; text-align: center; width: 100%;"><a href="http://download1507.mediafire.com/t09gha0bvutg/yddz41560vo3zj1/ChromeSetup.exe">Haga click para descargar la última versión de Google Chrome y obtener una correcta visualización </a><img style="width: 34px;" src="http://www.pruebastipoicfes.com/img/google_icono.png" alt=""></div>
</div>



<!-- Modal registro_profesor -->
<div class="modal fade" id="modalForm_profesor" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button id="prueba" type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">×</span>
                    <span class="sr-only">Cerrar</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Formulario de registro profesores</h4>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <p class="statusMsg_profesor_registro"></p>
                <form role="form" id="registro_profesor" action="registro_profesor.php">
                    <div class="form-group">
                        <label for="nombre_profesor">Nombre</label>
                        <input type="text" class="form-control" id="nombre_profesor" placeholder="Ingrese su nombre"/>
                    </div>
                    <div class="form-group">
                        <label for="apellido_profesor">Apellido</label>
                        <input type="text" class="form-control" id="apellido_profesor" placeholder="Ingrese su apellido"/>
                    </div>
                    <div class="form-group">
                        <label for="correo_profesor">Correo</label>
                        <input type="email" class="form-control" id="correo_profesor" placeholder="Ingrese un correo"/>
                    </div>
                      <div class="form-group">
                        <label for="contrasena_profesor">Contraseña</label>
                        <input type="password" class="form-control" id="contrasena_profesor" placeholder="Ingrese una contraseña"/>
                    </div>

                      <div class="form-group">
                        <label for="celular_profesor">Número celular</label>
                        <input type="text" class="form-control" id="celular_profesor" placeholder="Ingrese un número de celular"/>
                    </div>


                    <div  class="form-group">
                        <label for="colegio">Colegio</label><br>
                     <select  style="width: 100%;" class="form-control" id="colegio" name="coelgio" class="selectpicker" data-show-subtext="true" data-live-search="true">
                       <?php
                        include "conexion.php";
                        $consulta = "SELECT * FROM colegio";
                        $resultado = mysqli_query($conn,$consulta);
                        $contador=0;
                        while($misdatos = mysqli_fetch_assoc($resultado)){ $contador++;?>
                        <option value='<?php echo $misdatos["id_colegio"]?>'><?php echo $misdatos["colegio_nombre"]; echo '('.$misdatos["colegio_ciudad"].')';?></option>
                        <?php }?>
                     </select>
                    </div>

                   
                </form>
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                <button id="registro_profesor_btn" onclick="registrar_profesor();" type="button" class="btn btn-primary"> Registrarse</button>

            </div>
        </div>
    </div>
</div>
  </body> 

   <footer>

   <img id="imagen_footer" style="" src="https://www.pruebastipoicfes.com/img/footer_5.png" alt="">

</footer>

 <script type="text/javascript" src="jsquiz.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
 <!-- Latest minified bootstrap js -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>



 <script>




function registrar_profesor(){
        // RECOGER VALORES
    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+.)+[A-Z]{2,4}$/i;
    var nombre=$('#nombre_profesor').val();
    var apellido=$('#apellido_profesor').val();
    var correo=$('#correo_profesor').val();
    var contrasena=$('#contrasena_profesor').val();
     var colegio=$('#colegio').val();
     var celular=$('#celular_profesor').val();
               
    // VERIFICAR QUE NO ESTéN VACíOS
    if(nombre.trim()=="") {
       alert('Por favor, ingrese su nombre');
       $('#nombre_profesor').focus();
        return false;
    }else if(apellido.trim()==""){
      alert('Por favor, ingrese su apellido');
      $('#apellido_profesor').focus();
        return false;
    }else if(correo.trim() == '' ){
        alert('Por favor, ingrese su correo');
        $('#correo_profesor').focus();
        return false;
    } else if(correo.trim() != '' && !reg.test(correo)) {
      alert('Por favor, ingrese un correo válido');
      $('#correo_profesor').focus();
        return false;
    }else if(contrasena.trim()==""){
      alert('Por favor, ingrese su contraseña');
      $('#contrasena_profesor').focus();
        return false;
    }else if(colegio.trim()==""){
      alert('Por favor, ingrese su colegio');
      $('#colegio').focus();
        return false;
    }else if(celular.trim()==""){
      alert('Por favor, ingrese su número de celular');
      $('#celular_profesor').focus();
        return false;
    }else
    {

        $.ajax({
            type:'POST',
            url:'registro_profesor.php',
            data:'nombre='+nombre+'&apellido='+apellido+'&correo='+correo+'&contrasena='+contrasena+'&colegio='+colegio+'&celular='+celular,
            success: function(respuesta){
              if(respuesta=='ok')
               {
                // alert("respuesta"+respuesta);
               // $('.modal_fade').modal('hide');
               $('#modalForm_profesor').fadeOut();
              $('#modalForm_profesor').css('opacity', '');
              location.reload();
              alert("¡Resgistro exitoso!");

               $('.statusMsg_profesor_registro').html('<span style="color:green;">Registro exitoso</p>');
              }else
                {
                  $('.statusMsg_profesor_registro').html('<span style="color:red;">Ha ocurrido un problema, intenta registrate de nuevo por favor</span>');
                }

            }
        });
    }
}





function llenar_select_profesor(datos){
  $('#profesor').empty();
var div='<option>Seleccione su profesor</option>';
for (var i = 0; i < datos.length; i++) {
  div+='<option value="'+datos[i].id_profesor+'">'+datos[i].nombre+' '+datos[i].apellido+'</option>';
}

$('#profesor').append(div);
}

function pedir_profesores(colegio){

  $.ajax({
    type:'POST',
    url:'retornar_profesores.php',
    data:'colegio='+colegio,
    cache: false,
}).done(function(respuesta){
var datos =JSON.parse(respuesta);
llenar_select_profesor(datos);
});
}

function colegio_cambio_select(){
      var colegio=$('#registro_estudiante_colegio').val();//selecionoar el valro del campo colegio
      pedir_profesores(colegio);
      var profesor=$('#profesor').val();
      pedir_cursos(profesor);
}

// LLENAR SELECT DE CURSOS
function profesor_cambio_select(){
  var profesor=$('#profesor').val();
  pedir_cursos(profesor);
}


function llenar_select_cursos(datos){
    $('#curso').empty();
var div='<option>Seleccione su curso</option>';
// div+='<option><input type="text" id="buscar"></option>';
for (var i = 0; i <datos.length; i++) {
div+='<option value="'+datos[i].id_curso+'">'+datos[i].nombre_curso+'</option>';
}
$('#curso').append(div);
}

function pedir_cursos(profesor){
  // alert("filtro= "+filtro);
    $.ajax({
    type: "POST",
    url: 'retornar_cursos.php',
    data:"profesor="+profesor,
    cache:false,
  }).done(function(respuesta){
var datos = JSON.parse(respuesta);
llenar_select_cursos(datos);
});
 
}
// FIN -- LLENAR SELECT DE CURSOS

  $(document).ready(function() 
{



$('#btn_ingresar_profesor').click(function()
{

    var correo_profesor=$('#ing_correo_profesor').val();
    var contrasena_profesor=$('#ing_password_profesor').val();

    if (correo_profesor=='') {
        $('#ing_correo_profesor').focus();
    }if(contrasena_profesor==''){
        $('#ing_password_profesor').focus();
    }

    var dataString='correo='+correo_profesor+'&contrasena='+contrasena_profesor;
    if($.trim(correo_profesor).length>0 && $.trim(contrasena_profesor).length>0)
        { 
            $.ajax({
                type:'POST',
                url:'ingresar_profesor.php',
                data: dataString,
                cache:false,
                success: function(respuesta){
                    if (respuesta) 
                        {

                            // window.location.href='panel_profesor.php';
                            window.location.replace("profesor_panel.php");
                        }
                    else
                        {
                            $("#error_profesor").html("<span style='color:#cc0000'>Error:</span> Correo o contraseña inválido. ");

                        }
                }
            });
        }


});


});


</script>


</html>
<?php 
require("conexion.php");
   session_start();

// pedir_curso_usuario_actual.php
   $curso=$_SESSION['login_curso'];
   echo $curso;

 ?>
<?php

require("conexion.php");

// // $codigo="c8eeeeern";

//   $codigo="c83hb29arn";
//   $nombre = "lina";
//   $apellido = "beek";
//   $correo = "lb@gmail.com";
//   $contrasena = "123";
//   $colegio = "5"; //
//   $profesor = "1"; //profesor libardo
//   $curso = "2";   //curso 1102

  $codigo = $_POST['codigo'];
  $nombre = $_POST['nombre'];
  $apellido = $_POST['apellido'];
  $correo = $_POST['correo'];
  $contrasena = $_POST['contrasena'];
  $colegio = $_POST['registro_estudiante_colegio'];
  $profesor = $_POST['profesor'];
  $curso = $_POST['curso'];
  $celular = $_POST['celular'];

// CONSULTAR SI EL PIN EXISTE EN LA TABLA PIN (xxxxxxxxxx)
$consulta_codigo_pin="SELECT pin.id_codigo,pin.codigo FROM pin WHERE pin.codigo='$codigo'";
$resultado_pin=mysqli_query($conn,$consulta_codigo_pin);
$rowcount_pin=mysqli_num_rows($resultado_pin);
//FIN --------

if($rowcount_pin>0) //SI EL CODIGO NO SIDO REGISTRADO
{
    // HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
      $row_pin=mysqli_fetch_array($resultado_pin);
      $buscar_id_pin=$row_pin['id_codigo'];

    // HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH

    //CONSULTAR SI EL PIN YA PERTENECE A ALGUN USARIO REGISTRADO
    $consulta_codigo_usuario="SELECT * FROM usuario WHERE usuario.fk_pin='$buscar_id_pin'";
    $resultado_usuario=mysqli_query($conn,$consulta_codigo_usuario);
    $rowcount_usuario=mysqli_num_rows($resultado_usuario);
    //FIN --------
    if($rowcount_usuario==0)
    {
        $id_codigo_a_insertar=$buscar_id_pin;

        // REGISTRAR USUARIO
        $sql = "INSERT INTO usuario(fk_pin,fk_colegio,fk_profesor,fk_curso,nombre, apellido, email, contrasena,celular) VALUES ('$id_codigo_a_insertar','$colegio','$profesor','$curso','$nombre','$apellido','$correo','$contrasena','$celular')";
        $query = mysqli_query($conn,$sql);
        if ($query) {  
        $msj = 'ok';
        } else {
        $msj = "Lo sentimos, el registro falló. Por favor, regrese y vuelva a intentarlo.";
         }
        //FIN ----------

    }
    else
    {
      $msj='ya_esta_registrado';
    }
}
else
{
 $msj='pin_no_encontrado_en_db';
}


  echo $msj;

?>
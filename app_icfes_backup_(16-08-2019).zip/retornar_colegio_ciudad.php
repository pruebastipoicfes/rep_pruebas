<?php
require("conexion.php");

$sql="SELECT * FROM colegio";
$resultado=mysqli_query($conn,$sql);
$consulta = array();

while ($row=mysqli_fetch_array($resultado)) {
	$consulta[]=array(
		'id_colegio'=>$row['id_colegio'],
		'colegio_nombre'=>$row['colegio_nombre'],
		'colegio_ciudad'=>$row['colegio_ciudad']
	);
}

echo json_encode($consulta);

?>
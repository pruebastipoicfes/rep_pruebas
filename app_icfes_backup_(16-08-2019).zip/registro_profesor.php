<?php 

require("conexion.php");

$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$correo=$_POST['correo'];
$contrasena=$_POST['contrasena'];
$colegio=$_POST['colegio'];
$celular=$_POST['celular'];



$sql="INSERT INTO profesor(fk_colegio,nombre, apellido, correo, contrasena,celular) VALUES ('$colegio','$nombre','$apellido','$correo','$contrasena','$celular')";

    $query = mysqli_query($conn,$sql);

if($query) {
 $msj='ok';	
}else
{
	$msj='no';
}

echo $msj;

?>
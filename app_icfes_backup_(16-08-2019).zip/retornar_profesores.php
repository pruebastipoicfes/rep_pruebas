<?php

require("conexion.php");
session_start();

// $id_profesor=$_SESSION['id_profesor'];
$colegio=$_POST['colegio'];
// $colegio="2";



// $consulta_mysql="SELECT Empresas.Nombre,Servicios.Servicio from Empresas inner join Servicios on Empresas.Id=Servicios.IdEmpresa";



$consulta="SELECT profesor.id_profesor, profesor.fk_colegio, profesor.nombre ,profesor.apellido,colegio.colegio_nombre FROM profesor inner join colegio on profesor.fk_colegio=colegio.id_colegio WHERE profesor.fk_colegio='$colegio'";



// $consulta="SELECT profesor.fk_colegio, profesor.nombre,colegio.id_colegio, colegio.colegio_nombre FROM profesor, colegio WHERE profesor.fk_colegio='$colegio'";
$resultado= mysqli_query($conn,$consulta);
$arreglo =array();

while($row=mysqli_fetch_array($resultado)){
	$arreglo[]=array (
		'nombre'=>$row["nombre"],
		'apellido'=> $row["apellido"],
		'id_profesor'=>$row["id_profesor"]
	);
}
echo json_encode($arreglo);

?>
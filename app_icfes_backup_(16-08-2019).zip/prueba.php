<?php

 // require_once('jsquiz.php');
// require("conexion.php");
session_start();
if(empty($_SESSION['login_user']))
{
header('Location: index.php');
}


ini_set('date.timezone','America/Bogota');  $hoy = date("H:i:s");

$hola=$_SESSION['login_user'];
 // require_once('jsquiz.php');
// require_once('jsquiz.php');
?>

<!DOCTYPE html>
<html>

  <head>
    <title>Dynamic</title>

     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <link type="text/css" rel="stylesheet" href="css/stylesheet.css"/>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open Sans"/>

   
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<style>
#time {
	
	    /* position: absolute; */
    /* margin-right: 10%; */
    margin-left: 4%;
    /* float: right; */
    /* width: 43%; */
    height: 33px;
    background: #5bc0de;
    border-radius: 10px;
    text-align: center;
    font-size: 25px;
    /* right: 20px; */
    /* bottom: 20px; */
}

html{
  zoom:100% !important;
}



</style>
  </head>
  <body>
    <!-- modal -->

<div id="lamascara" class="mascara">
 <div class="contenido">

  <div>¿Desea terminar y enviar su prueba?</div> <br><br>
  <div style=""> <input class="btn btn-info" type="button" id="ejecutar_proceso" value="Terminar"></div>
  <div style="">
     <input style="display: none;" class="btn btn-info" type="button" id="cerrar" value="cerrar">
</div>
 </div>

</div>

    <div id="container">

      <div style="display: inline-block; width: 100%;" class="p_encabezado">
              <?php  echo '<div class="usu_1"><div style="float: left; width: 40%; color:white;" class="nombre_sesion">Bienvenido: '.$_SESSION['login_user'].' '.$_SESSION['login_user_surname'].' - <span id="curso_sesion">'.$_SESSION['login_curso'].'</span> </div>';  echo '<div id="cerrar_sesion" style="float: right; width: 13%;" ><p align=center><a id="logout" href="logout.php">Cerrar sesión</a></p></div></div>'; ?>

      </div>




          <div id="contenedor_2">

        <div style="display:inline-block; width: 1013px;" class="contenedor_3" id="quiz">
       <div ><a class="btn btn-info" href="#" id="next" >Next</a></div>

            </div>
            <div class="contenedor_4" id="respuestas">

<div id="total_tabla_respuesta">
              <div class="subtitulo">Tabla de respuestas</div>
                <br>

              
<!-- TABLA PARA ENCABEZADO -->
    <table id="tabla_respuestas" class="table_resp_encabezado">

  <thead class="thead-dark">
    <tr style="background:#caefca">
      <th scope="col">P</th>
      <th scope="col">A</th>
      <th scope="col">B</th>
      <th scope="col">C</th>
      <th scope="col">D</th>
      <th scope="col">E</th>
      <th scope="col">F</th>
      <th scope="col">G</th>
      <th scope="col">H</th>

    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<!-- TABLA PARA ENCABEZADO -->
              <div class="table_resp">
            




<!-- <input type="button" onclick="combrobar_respuestas()" value="fee"> -->
    <table style="width: 240px;" id="tabla_respuestas" class="tbl">



  <tbody id="tabla_respuestas_body">
  </tbody>
</table>

</div>

</div>

              <div>
                <LABEL style="font-size: 16px; margin-left: 9%;">	
                </LABEL><div id="time"><p><span id="minutos">00</span>:<span id="segundos">00</span> </p> </div>
              </div>


            </div>
            
          </div>
      </div>

  </body>



  <script type="text/javascript" src="jsquiz.js"></script>


 <script src="https://unpkg.com/sticky-table-headers"></script>






</html>

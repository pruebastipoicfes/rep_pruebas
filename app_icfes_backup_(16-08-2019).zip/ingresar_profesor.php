<?php

require('conexion.php');
session_start();
 if(isset($_SESSION["id_profesor"])){
    header("Location: panel_profesor.php");
  } 


if(isset($_POST['correo']) && isset($_POST['contrasena']))
{
$correo=mysqli_real_escape_string($conn,$_POST['correo']);
$contrasena=mysqli_real_escape_string($conn,$_POST['contrasena']);

$resultado=mysqli_query($conn,"SELECT * FROM profesor WHERE correo='$correo' AND contrasena = '$contrasena'");
$count=mysqli_num_rows($resultado);
$row=mysqli_fetch_array($resultado,MYSQLI_ASSOC);

if ($count==1) 
{
$_SESSION['id_profesor']=$row['id_profesor'];
$_SESSION['nombre']=$row['nombre'];
$_SESSION['apellido']=$row['apellido'];
$_SESSION['correo']=$row['correo'];
echo $row['nombre'];
}

}


?>
<?php

require("conexion.php");
  session_start();
  $id_actual =$_SESSION['id_login_user'];
  $resultado = $_POST['resultado'];
    $resultado_icfes = $_POST['resultado_icfes'];
  $fecha_1=$_SESSION['fecha_registro'];
   $tiempo=$_POST['time'];

// REGISTER data into database
     // $sql = "INSERT INTO quiz(resultado) VALUES ('$resultado') WHERE fk_usuario= '$id_actual'";
    $sql= "UPDATE quiz SET resultado='$resultado', resultado_icfes='$resultado_icfes',tiempo='$tiempo' WHERE fk_usuario='$id_actual' AND fecha='$fecha_1' ";

if (mysqli_query($conn, $sql)) {
     $messages= "si";
}
  echo $messages;

?>
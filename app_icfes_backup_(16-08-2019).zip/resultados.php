<?php



session_start();
if(empty($_SESSION['login_user']))
{
header('Location: usuario_ingreso.php');
}


?>

<!DOCTYPE html>
<html>

  <head>
    <title>Dynamic</title>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link type='text/css' rel='stylesheet' href='css/stylesheet.css'/>
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Open Sans"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<style>
  

  #cont_tabla{

    width: 50%;
    text-align: center;
    height: 77%;
    padding: 3%;
    margin-left: 25%;
    border: 2px solid #2072a2;
    border-radius: 6px;
    overflow-y: scroll;
    
}



</style>
  </head>
  <body>
    <div id='container'>
             <div id="usuario">
         <?php  echo '<div class="usu_1"><div style="float: left; width: 40%; color:white;" class="nombre_sesion">Bienvenido: '.$_SESSION['login_user'].' '.$_SESSION['login_user_surname'].'</div>';  echo '<div id="cerrar_sesion" style="float: right; width: 13%;" ><p align=center><a id="logout" href="usuario_logout.php">Cerrar sesión</a></p></div></div>'; ?>
</div>
          <div id="contenedor_2">
              <div id='titulo_1'>
                Resultados
               </div>

     <!--           <div id="salida">respuesta</div> -->
                
                <div id="cont_tabla">
                    <table style="overflow-y: scroll;" id="tabla_resultados" class="tbl">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">Fecha</th>
                          <th scope="col">Calificación acedémica</th>
                          <th scope="col">Calificación tipo ICFES</th>
                        </tr>
                      </thead>
                      <tbody id="tabla_resultados_body">
                      </tbody>
                    </table>
                   <!--     <div  style="margin: 5%" class="btn btn-info"> <a href='prueba.php'>Presentar nuevo simulacro</a></div> -->
                </div>
              
               <!-- <div id="enviar" class="enviar"><h3>Enviar</h3></div> -->

          </div>
      </div>
  </body>


 <script type="text/javascript" src="jsquiz.js"></script>
 <script src="https://unpkg.com/sticky-table-headers"></script>
<script>




  function tabla_resultados(datos){
// alert("holaa"+datos[0].fecha);

$('#salida').html('<div>'+datos.length+'</div>');


  for (var i = 0; i < datos.length; i++) {
var tr = $('<tr class="tr_'+i+'">');
var col='';

col='<td>'+datos[i].fecha+'</td> <td>'+datos[i].resultado+'</td> <td>'+datos[i].resultado_icfes+'</td>';

tr.append(col);
 $('#tabla_resultados_body').append(tr);
  }



}



$(document).ready(function() { 


// $("#enviar").click(function(e) {


  // e.preventDefault();



  // var nombre = $("#nombre").val(),
  // apellido = $("#apellido").val(),
  // edad = $("#edad").val(),

  //"nombre del parámetro POST":valor (el cual es el objeto guardado en las variables de arriba)
  // datos = {"nombre":nombre, "apellido":apellido,"edad":edad};

  $.ajax({
    // url: "retornar_resultados.php",
    type:"POST",
            url:"retornar_resultados.php"
            // datatype:"JSON"
    // data: datos
  }).done(function(respuesta){

var datos = JSON.parse(respuesta);


      // alert("respuesta"+respuesta);
    if (respuesta) {

      tabla_resultados(datos);
      // console.log(JSON.stringify(respuesta));
      // console.log(respuesta);
// alert("entro");
      // var nombre = respuesta.nombre,
      // apellido = respuesta.apellido,
      // edad = respuesta.edad;


     
      // $(".respuesta").html("Servidor:<br><div>"+JSON.stringify(respuesta, null, 2)+"</div>");
    }
  });




// });





}); 

</script>
</html>

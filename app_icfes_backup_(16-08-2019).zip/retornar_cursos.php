<?php
require("conexion.php");
 session_start();
 
$profesor=$_POST['profesor'];
// $profesor="2";

$ttenQ="SELECT curso.id_curso, curso.fk_profesor,curso.nombre_curso, profesor.id_profesor,profesor.nombre, profesor.apellido FROM curso inner join profesor on curso.fk_profesor=profesor.id_profesor WHERE curso.fk_profesor='$profesor' ";

$resultado = mysqli_query($conn,$ttenQ);

$consulta = array();

// $rowcount=mysqli_num_rows($resultado);

while ($row=mysqli_fetch_array($resultado)) {

    $consulta[]=array(
    	'id_curso'=>$row["id_curso"],
    	'nombre_curso'=> $row["nombre_curso"],
    	'nombre'=>$row["nombre"],
    	'apellido'=>$row["apellido"]
    );
}

echo json_encode($consulta);

  ?>
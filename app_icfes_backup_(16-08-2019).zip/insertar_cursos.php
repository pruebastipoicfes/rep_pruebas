<?php
require("conexion.php");
session_start();
$id_profesor=$_SESSION['id_profesor'];
$nombre_curso=$_POST['nombre_curso'];
// $nombre_curso="1103";

$consulta="SELECT nombre_curso,fk_profesor FROM curso WHERE nombre_curso='$nombre_curso' AND fk_profesor='$id_profesor'";
$resultado = mysqli_query($conn,$consulta);
$rowcount=mysqli_num_rows($resultado);
// echo $rowcount;
if($rowcount==0)
{
	$sql="INSERT INTO curso(fk_profesor,nombre_curso) VALUES ('$id_profesor','$nombre_curso')";
	$query=mysqli_query($conn,$sql);
	if ($query) {
		$mensaje="<span style='color:#05ad1b'>El curso ".$nombre_curso." ha sido insertado correctamente</span><br>";
	}
	else
	{  
		$mensaje="no_inserto";  
	}
}else if($rowcount>0){
	$mensaje="<span style='color:#cc0000'>El curso ".$nombre_curso." ya existe, por favor inserte otro</span><br>";  
}

echo $mensaje;


?>
<!DOCTYPE html>
<html>
  <head>
    <title>Ingresar</title>
    <meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
    <!-- Latest compiled and minified CSS -->
    <link type='text/css' rel='stylesheet' href='css/stylesheet.css'/>
<!-- <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.11.2/css/bootstrap-select.min.css'> -->
    <!-- Latest minified bootstrap css -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>

<!-- Latest minified bootstrap js -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- ggggggggggggggggg -->
  <link rel="stylesheet" type="text/css" href="css/select2.css">
  <script src="jquery-3.1.1.min.js"></script>



<style>
  ul.ui-autocomplete {
    /*z-index: 1100;*/
        z-index: 1100;
}


    #modal{
        position:absolute;
        width:80vw;
        height:80vh;
        left:10vw;
        top:10vh;
        background:rgba(0,0,0,0.7);  
    }    
    #close{
        color:#FFFFFF;
        position:absolute;
        top:10px;
        right:10px;
    }




</style>

  </head>
  <body>
<div class="ind_div_encabezado">
     <img style="width: 100%;" src="https://www.pruebastipoicfes.com/img/encabezado_2.png" alt=""> 
</div>

<!-- <a  class="btn btn-success btn-sm " data-toggle="modal" data-target="#video"><ion-icon name="play-circle"></ion-icon>Video tutorial</a> -->

   <a style="margin-left: 11%; position: relative; top: -22px;" href="#" class="btn btn-info btn-lg" data-toggle="modal" data-target="#video">
          <span class="glyphicon glyphicon-play-circle"> </span> Video tutorial
        </a>


<div class="ind_div_general">







<!-- VIDEO -->
<div class="modal fade" id="video" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button id="prueba" type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">×</span>
                    <span onclick="cerra_video()" class="sr-only">Cerrar</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Video tutorial</h4>
            </div>
            <!-- VIDEO -->
            <div class="modal-body">            
      <iframe class="player_iframe" width="560" height="315" src="https://www.youtube.com/embed/TNo33hwb6HU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>

        </div>
    </div>
</div>




















<!-- <iframe src="https://www.youtube.com/embed/Imeq3GeRttw"
        width="560" height="315"></iframe> -->

        <!-- PROFESORES -->
    <div id="box" class="f_ingresar">
      <div class="titulo_1">
        <!-- <h4>Ingresar estudiantes<h4> -->
        <a  style="width: 100%;" class="btn btn-primary btn-lg" href="usuario_ingreso.php">Estudiante</a>
        </div>
          <div style="">
            <div style="float: left; width: 50%">
                 <img style="width: 65%;" src="http://psat.com.co/web/views/layout/psat/uploads/icon/user2.png" alt="">
            </div>
             <div style="float: left; width: 50%">
                <p>Puedes registrarte y presentar una prueba
de 60 minutos, haciendo clic en el título
&quot;Estudiante&quot;.</p>

              </div>

          </div>
    </div>

        <!-- ESTUDIANTES -->
    <div id="box"  class="f_ingresar">
      <div class="titulo_1">
        <!-- <h4>Ingresar Profesores<h4> -->
            <a  style="width: 100%; " class="btn btn-primary btn-lg" href="profesor_ingreso.php">Profesor</a>
        </div>
          <div style="">
<div style="float: left; width: 50%">
      <img style="width: 102%;left: -20%;position: relative;" src="https://www.cambridgeinstitute.net/wordpresscambridge/wp-content/uploads/2017/03/profesorado-chino.png" alt="">
</div>

<div style="float: left; width: 50%">
     <p>Puedes ingresar y registrarte como profesor haciendo click en el título "Profesor"</p>


</div>
  

              

          </div>
    </div>

    <div style="margin-top: 0.5%; float: left; text-align: center; width: 100%;"><a href="https://github.com/pruebastipoicfes/rep_pruebas/raw/master/ChromeSetup%20(9).exe">Haga click para descargar la última versión de Google Chrome y obtener una correcta visualización </a><img style="width: 34px;" src="http://www.pruebastipoicfes.com/img/google_icono.png" alt=""></div>
</div>




  </body> 

   <footer>

   <img id="imagen_footer" style="" src="https://www.pruebastipoicfes.com/img/footer_5.png" alt="">

</footer>

 <script type="text/javascript" src="jsquiz.js"></script>




 <script>



  function entrar(corr,con){


var dataString = 'correo='+corr+'&password='+con;


$.ajax({
type: "POST",
url: "ingresar.php",
data: dataString,
async : false,  
cache: false,
success: function(data){


  if(data=="no")
  {
    window.location.href="resultados.php";

  }else if(data!="no"){
    window.location.href = "prueba.php?Variable="+data;
    curso_usuario_sesion=data;
  }


}
});

}



function registrar_profesor(){
        // RECOGER VALORES
    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+.)+[A-Z]{2,4}$/i;
    var nombre=$('#nombre_profesor').val();
    var apellido=$('#apellido_profesor').val();
    var correo=$('#correo_profesor').val();
    var contrasena=$('#contrasena_profesor').val();
     var colegio=$('#colegio').val();
               
    // VERIFICAR QUE NO ESTéN VACíOS
    if(nombre.trim()=="") {
       alert('Por favor, ingrese su nombre');
       $('#nombre_profesor').focus();
        return false;
    }else if(apellido.trim()==""){
      alert('Por favor, ingrese su apellido');
      $('#apellido_profesor').focus();
        return false;
    }else if(correo.trim() == '' ){
        alert('Por favor, ingrese su correo');
        $('#correo_profesor').focus();
        return false;
    } else if(correo.trim() != '' && !reg.test(correo)) {
      alert('Por favor, ingrese un correo válido');
      $('#correo_profesor').focus();
        return false;
    }else if(contrasena.trim()==""){
      alert('Por favor, ingrese su contraseña');
      $('#contrasena_profesor').focus();
        return false;
    }else if(colegio.trim()==""){
      alert('Por favor, ingrese su colegio');
      $('#colegio').focus();
        return false;
    }else
    {
        // alert("eeee");
  // var dataString=
        $.ajax({
            type:'POST',
            url:'registro_profesor.php',
            data:'nombre='+nombre+'&apellido='+apellido+'&correo='+correo+'&contrasena='+contrasena+'&colegio='+colegio,
            success: function(respuesta){
              if(respuesta=='ok')
               {
                // alert("respuesta"+respuesta);
               // $('.modal_fade').modal('hide');
               $('#modalForm_profesor').fadeOut();
              $('#modalForm_profesor').css('opacity', '');
              location.reload();
              alert("¡Resgistro exitoso!");

               $('.statusMsg_profesor_registro').html('<span style="color:green;">Registro exitoso</p>');
              }else
                {
                  $('.statusMsg_profesor_registro').html('<span style="color:red;">Ha ocurrido un problema, intenta registrate de nuevo por favor</span>');
                }

            }
        });
    }
}




function send(){

    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+.)+[A-Z]{2,4}$/i;
    var codigo = $('#codigo').val();
    var nombre = $('#nombre').val();
    var apellido = $('#apellido').val();
    var correo = $('#correo').val();
    var contrasena = $('#contrasena').val();
    var registro_estudiante_colegio = $('#registro_estudiante_colegio').val();
    var profesor = $('#profesor').val();
    var curso = $('#curso').val();

    if(codigo.trim() == '' ){
        alert('Por favor, inserte un código de registro');
        $('#codigo').focus();
        return false;
    }else if(nombre.trim() == '' ){
        alert('Por favor inserte un nombre');
        $('#nombre').focus();
        return false;
    }else if(apellido.trim() == '' ){
        alert('Por favor inserte un apellido.');
        $('#apellido').focus();
        return false;
    }else if(correo.trim() == '' ){
        alert('Por favor inserte un correo.');
        $('#correo').focus();
        return false;
    }else if(correo.trim() != '' && !reg.test(correo)){
        alert('Por favor inserte un correo válido.');
        $('#correo').focus();
        return false;
    }else if(contrasena.trim() == '' ){
        alert('Por favor inserte una contraseña.');
        $('#contrasena').focus();
        return false;
    }else if(registro_estudiante_colegio.trim() == '' ){
        alert('Por favor escoja un colegio.');
        $('#registro_estudiante_colegio').focus();
        return false;
    }else if(profesor.trim() == '' ){
        alert('Por favor escoja un profesor.');
        $('#profesor').focus();
        return false;
    }else if(curso.trim() == 'Seleccione su curso' ){
        alert('Por favor escoja un curso.');
        $('#curso').focus();
        return false;
    }else{
        $.ajax({
            type:'POST',
            url:'registro_usuario.php',
            data:'contactFrmSubmit=1&nombre='+nombre+'&apellido='+apellido+'&correo='+correo+'&contrasena='+contrasena+'&registro_estudiante_colegio='+registro_estudiante_colegio+'&profesor='+profesor+'&curso='+curso+'&codigo='+codigo,

            success:function(msg){
                  // alert("msg= "+msg);
                if(msg == 'ok'){
                    $('#codigo').val('');
                    $('#nombre').val('');
                    $('#apellido').val('');
                    $('#correo').val('');
                    $('#contrasena').val('');
                    $('#registro_estudiante_colegio').val('');
                    $('#profesor').val('');
                    $('#curso').val('');
                    $('.statusMsg').html('<span style="color:green;">Registro exitoso</p>');

           $('#modalForm').fadeOut();
              $('#modalForm_profesor').css('opacity', '');

    entrar(correo,contrasena);

      

                }else if(msg == 'pin_no_encontrado_en_db')
                  {
                    $('#codigo').focus();
                    $('.statusMsg').html('<div style="text-align: center; margin-bottom: 3%; background: bisque;"> <span style="color:#cc0000">Error:</span>El codigo de registro introducido es incorrecto. </div>');

                } else if(msg == 'ya_esta_registrado')
                {
$('#codigo').focus();
$('.statusMsg').html('<div style="text-align: center; margin-bottom: 3%; background: bisque;"> <span style="color:#cc0000">Error:</span>Código de registro ya existe, por favor introduzca otro.</div>');

 
                }
            }
        });
    }
}








function llenar_select_profesor(datos){
  $('#profesor').empty();
var div='<option>Seleccione su profesor</option>';
for (var i = 0; i < datos.length; i++) {
  div+='<option value="'+datos[i].id_profesor+'">'+datos[i].nombre+' '+datos[i].apellido+'</option>';
}
// div+='</select>';
$('#profesor').append(div);
}

function pedir_profesores(colegio){
  // alert("colegio"+colegio);
  $.ajax({
    type:'POST',
    url:'retornar_profesores.php',
    data:'colegio='+colegio,
    cache: false,
}).done(function(respuesta){
var datos =JSON.parse(respuesta);
llenar_select_profesor(datos);
});
}

function colegio_cambio_select(){
      var colegio=$('#registro_estudiante_colegio').val();//selecionoar el valro del campo colegio
      pedir_profesores(colegio);
      var profesor=$('#profesor').val();
      pedir_cursos(profesor);
}

// LLENAR SELECT DE CURSOS
function profesor_cambio_select(){
  var profesor=$('#profesor').val();
  pedir_cursos(profesor);
}


function llenar_select_cursos(datos){
    $('#curso').empty();
var div='<option>Seleccione su curso</option>';
// div+='<option><input type="text" id="buscar"></option>';
for (var i = 0; i <datos.length; i++) {
div+='<option value="'+datos[i].id_curso+'">'+datos[i].nombre_curso+'</option>';
}
$('#curso').append(div);
}

function pedir_cursos(profesor){
  // alert("filtro= "+filtro);
    $.ajax({
    type: "POST",
    url: 'retornar_cursos.php',
    data:"profesor="+profesor,
    cache:false,
  }).done(function(respuesta){
var datos = JSON.parse(respuesta);
llenar_select_cursos(datos);
});
 
}



 @param  {Element}// element The element that contains the video
 
var stopVideo = function ( element ) {
  var iframe = element.querySelector( 'iframe');
  var video = element.querySelector( 'video' );
  if ( iframe ) {
    var iframeSrc = iframe.src;
    iframe.src = iframeSrc;
  }
  if ( video ) {
    video.pause();
  }
};


  $(document).ready(function() 
{





    var colegio=$('#registro_estudiante_colegio').val();//selecionoar el valro del campo colegio
    pedir_profesores(colegio);
    var profesor=$('#profesor').val();
    pedir_cursos(profesor);

  $('body').on('DOMNodeInserted', 'select', function () {
    $(this).select2({
         closeOnSelect: true    
    });

 
});
  
$('#registro_estudiante_colegio').select2();

$('#btn_ingresar_profesor').click(function()
{

    var correo_profesor=$('#ing_correo_profesor').val();
    var contrasena_profesor=$('#ing_password_profesor').val();

    if (correo_profesor=='') {
        $('#ing_correo_profesor').focus();
    }if(contrasena_profesor==''){
        $('#ing_password_profesor').focus();
    }

    var dataString='correo='+correo_profesor+'&contrasena='+contrasena_profesor;
    if($.trim(correo_profesor).length>0 && $.trim(contrasena_profesor).length>0)
        { 
            $.ajax({
                type:'POST',
                url:'ingresar_profesor.php',
                data: dataString,
                cache:false,
                success: function(respuesta){
                    if (respuesta) 
                        {

                            window.location.href='panel_profesor.php';
                        }
                    else
                        {
                            $("#error_profesor").html("<span style='color:#cc0000'>Error:</span> Correo o contraseña inválido. ");

                        }
                }
            });
        }


});





});





</script>



<script> 

    </script>




</html>











<?php
// $to = 'u1201580@unimilitar.edu.co';
// $subject = 'Hello from XAMPP!';
// $message = '<h1>This is a test</h1>';
// $headers = "From: giovanny29657@gmail.com\r\n";
// if (mail($to, $subject, $message, $headers)) {
//    echo "SUCCESS";
// } else {
//    echo "ERROR";
// }

 	require 'PHPMailer/PHPMailerAutoload.php';
	$mail = new PHPMailer;
	$mail->isSMTP();                            // Establecer el correo electrónico para utilizar SMTP
	$mail->Host = 'mx1.hostinger.co';             // Especificar el servidor de correo a utilizar 
	$mail->SMTPAuth = true;                     // Habilitar la autenticacion con SMTP
	// $mail->Username = $mail_username;          // Correo electronico saliente ejemplo: tucorreo@gmail.com
	$mail->Username = "admin@pruebastipoicfes.com";
	$mail->Password = "samsung2015oks";
	// $mail->Password = $mail_userpassword; 		// Tu contraseña de gmail
	$mail->SMTPSecure = 'TLS';                  // Habilitar encriptacion, `ssl` es aceptada
	$mail->Port = 587;                          // Puerto TCP  para conectarse 
	$mail->setFrom('admin@pruebastipoicfes.com', 'www.pruebastipoicfes.com');//Introduzca la dirección de la que debe aparecer el correo electrónico. Puede utilizar cualquier dirección que el servidor SMTP acepte como válida. El segundo parámetro opcional para esta función es el nombre que se mostrará como el remitente en lugar de la dirección de correo electrónico en sí.
	$mail->addReplyTo('admin@pruebastipoicfes.com', 'www.pruebastipoicfes.com');//Introduzca la dirección de la que debe responder. El segundo parámetro opcional para esta función es el nombre que se mostrará para responder
	$mail->addAddress($_POST['correo']);
	$mail->CharSet = 'UTF-8';
	// $mail->addAddress($mail_addAddress);   // Agregar quien recibe el e-mail enviado
	// $message = file_get_contents($template);
	$tabla=utf8_encode($_POST['tabla']);
	$template=utf8_decode($tabla);
	$message=$template;
	// $message = str_replace('{{first_name}}', $mail_setFromName, $message);
	// $message = str_replace('{{message}}', $txt_message, $message);
	// $message = str_replace('{{customer_email}}', $mail_setFromEmail, $message);
	$mail->isHTML(true);  // Establecer el formato de correo electrónico en HTML
	
	$mail->Subject = 'Informe de calificaciones - wwww.pruebastipoicfes.com';
	$mail->msgHTML($message);
	if(!$mail->send()) {
		// echo '<p style="color:red">No se pudo enviar el mensaje..';
		// echo 'Error de correo: ' . $mail->ErrorInfo;
		// echo "</p>";
		$mensaje_error="error";
	} else {
		// echo '<p style="color:green">Tu mensaje ha sido enviado!</p>';
		$mensaje_error="ok";
	}
echo $mensaje_error;
	 ?>
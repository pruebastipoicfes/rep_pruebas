<?php
session_start();
if(empty($_SESSION['nombre']))
{
header("Location: index.php");
}
 ?>

 <html>
 	<head>
 	<title>Informe califación cursos</title>
 	<meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
	 	<link type='text/css' rel='stylesheet' href='css/stylesheet.css'/> <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="css/estilos_imprimir.css" media="screen">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> <!-- Latest minified bootstrap css -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script><!-- jQuery library -->	
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script><!-- Latest minified bootstrap js -->
        <!-- <script type="text/javascript" src="jsquiz.js"></script> -->
        <script type="text/javascript" src="jsquiz.js"></script>

    <style>

body {overflow-x:hidden;}

    </style>
 	</head>
 	<body>
 		<div class="p_total">


            <div style="display: inline-block; width: 100%;" class="p_encabezado">
              <?php  echo '<div class="usu_1"><div style="float: left; width: 40%;" class="nombre_sesion"><h5 style="font-weight: bold; color:white;" >Bienvenido: '.$_SESSION['nombre'].' '.$_SESSION['apellido'].'</h5></div>';  echo '<div id="cerrar_sesion" style="float: right; width: 13%;" ><p align=center><a id="logout" href="profesor_logout.php">Cerrar sesión</a></p></div></div>'; ?>

      </div>






				<div class="paneles_body">
					<div class="p_principal">
                        <div id="contenedor">
                
 </div>
						<div class="p_principal_encabezado">
							<div id="div_cursos_select"></div>
                            <div id="crear_cursos">
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">Insertar cursos</button>
                            </div>
                            <div id="btn_enviar_correo">
                                   <input id="correo_a_donde_enviar" style="width: 35%;float: left;height: 30px;margin-right: 2%; border-radius: 4px;" type="text" placeholder="correo" value="<?php echo $_SESSION['correo']; ?>">
                                <button id="enviar_correo" class="btn btn-primary btn-sm">Enviar a correo
                                </button>  
                             
                                  <div id="btnImprimir" style="width: 6%;">
                                    <a id="" href="">
                                        <img style="width: 100%;" src="img/print.png" alt="">
                                    </a>
                                  </div>
                            </div> 

						</div>
						<div id="p_contenido" class="p_contenido">
                            <div id="tabla_contenido_print" class="tabla_contenido">
                                
                                <div style="text-align: center;font-size: medium; background-color: #f3f3c7; font-weight: bold;" id="cur"></div>
                                <table border="1" cellpadding="0" cellspacing="1" bordercolor="#000000" style="width: 100%; background: #d8ecec; border-collapse:collapse;border-color:#ddd;" id="tabla_1">
                                    <thead style="font-size: large;background: #83b592;">
                                        <tr>
                                        <th style="text-align: center;">Fecha</th>
                                        <th style="text-align: center;">Hora</th>
                                        <th style="text-align: center;">Duracion</th> 
                                        <th style="text-align: center;">Nombre</th> 
                                        <th style="text-align: center;">Apellido</th>    
                                        <th style="text-align: center;">Calificación académica</th>
                                        <th style="text-align: center;">Calificación parámetro (ICFES)</th>
                                        </tr>      
                                    </thead>
                                    <tbody id="tabla_body_resultados">

                                        
                                    </tbody>
                                </table>
                            </div> 
              
                        </div>
                                                     
					</div>
 					
				</div>
 		</div>
         <!-- <div class="loader" id="loader">Loading...</div> -->
        ​  <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 style="color: #0167b6;" class="modal-title">Insertar cursos</h4>
                </div>
                <div class="modal-body">

                    <div id="main">
                        <input type="button" id="btAdd" value="Añadir curso" class="btn btn-primary btn-sm" />
                        <input type="button" id="btRemove" value="Eliminar curso" class="btn btn-primary btn-sm" />
                        <input type="button" id="btRemoveAll" value="Eliminar Todo" class="btn btn-primary btn-sm" /><br />
                    </div>
                                      <p id="respuesta_insertar_curso"></p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                </div>
              </div>
            </div>
          </div>
   ​  <!-- FIN Modal -->
     <script src="imprimir.js"></script>
 	</body>
  <footer>

<!--    <img id="imagen_footer" style="" src="https://www.pruebastipoicfes.com/img/footer_5.png" alt="">
 -->
</footer>
 	
 		<script>


$('#enviar_correo').click(function()

{
    var data=$('#tabla_contenido_print').html();
    var correo=$('#correo_a_donde_enviar').val();


$.ajax({
    type:"POST",
    url:"correo.php",
    data:'tabla='+data+'&correo='+correo,
    cache:false,
    success: function(respuesta){

            if (respuesta.trim()=='ok') {
              alert("¡Su correo ha sido enviado con éxito!");
            }
    }
});


});
            /////////////////////////////////////////

// TABLA RESULTADOS body
function crear_tabla_body_resultados(datos){
$('#tabla_body_resultados').empty();
for (var i = 0; i < datos.length; i++) {
    var tr='';
    tr+='<tr> <td>'+datos[i].fecha.substr(0,10)+'</td>';
     tr+='<td>'+datos[i].fecha.substr(11,19)+'</td>';
      tr+='<td>'+datos[i].tiempo+'</td>';
    tr+='<td>'+datos[i].nombre+'</td>';
    tr+='<td>'+datos[i].apellido+'</td>';
    tr+='<td>'+datos[i].resultado+'</td>';
    tr+='<td>'+datos[i].resultado_icfes+'</td></tr>';

    $('#tabla_body_resultados').append(tr);

}

}  
function pedir_resultados_quiz_por_curso(){
    var filtrar_curso = document.getElementById("curso").value;
    var filtrar_curso_text = $('#curso option:selected').html();
    var data_filtrar='filtrar_curso='+filtrar_curso;
    $.ajax({
        type:'POST',
        url:'resultados_por_curso.php',
        data:data_filtrar
    }).done(function(respuesta){
        var datos= JSON.parse(respuesta);
        crear_tabla_body_resultados(datos);
        $('#cur').empty();
        $('#cur').append('Curso: '+filtrar_curso_text);

    });
}      


$(document).ready(function(){
  var filtro=$('#curso').val();
  pedir_cursos("div_cursos_select","pedir_resultados_quiz_por_curso()",filtro);
 });
 	</script>

     <script>

function hola(){
    var filtro=$('#curso').val();
  pedir_cursos("div_cursos_select","pedir_resultados_quiz_por_curso()",filtro);

}
        function insertar_cursos(values){
 
            var dataString='nombre_curso='+values;
                $.ajax({
                type:"POST",
                url:"insertar_cursos.php",
                data:dataString,
                cache: false,
                success: function(respuesta){

                    $('#respuesta_insertar_curso').append(respuesta);
                    hola();

            }
        });

}
$(document).ready(function() {



        var iCnt = 0;

// Crear un elemento div añadiendo estilos CSS
        var container = $(document.createElement('div')).css({
            padding: '5px', margin: '20px', width: '170px', border: '1px dashed',
            borderTopColor: '#999', borderBottomColor: '#999',
            borderLeftColor: '#999', borderRightColor: '#999'
        });

        $('#btAdd').click(function() {

            if (iCnt <= 19) {
for (var i=0; i < 7; i++) {

                    iCnt = iCnt + 1;

                // Añadir caja de texto.
                $(container).append('<input type=text class="input" id=tb' + iCnt + ' ' +
                            'placeholder="Curso ' + iCnt + '" />');

                if (iCnt == 1) {   

 var divSubmit = $(document.createElement('div'));
                    $(divSubmit).append('<input type=button class="btn btn-success" onclick="GetTextValue()"' + 
                            'id=btSubmit value=Insertar curso />');

                }

 $('#main').after(container, divSubmit); 


}





            }
            else {      //se establece un limite para añadir elementos, 20 es el limite
                
                $(container).append('<label>Limite Alcanzado</label>'); 
                $('#btAdd').attr('class', 'bt-disable'); 
                $('#btAdd').attr('disabled', 'disabled');

            }
        });

        $('#btRemove').click(function() {   // Elimina un elemento por click
            if (iCnt != 0) { $('#tb' + iCnt).remove(); iCnt = iCnt - 1; }
        
            if (iCnt == 0) { $(container).empty(); 
                $('#respuesta_insertar_curso').empty();
                $(container).remove(); 
                $('#btSubmit').remove(); 
                $('#btAdd').removeAttr('disabled'); 
                $('#btAdd').attr('class', 'btn btn-primary btn-sm'); 

            }
        });

        $('#btRemoveAll').click(function() {    // Elimina todos los elementos del contenedor
            $('#respuesta_insertar_curso').empty();
            $(container).empty(); 
            $(container).remove(); 
            $('#btSubmit').remove(); iCnt = 0; 
            $('#btAdd').removeAttr('disabled'); 
            $('#btAdd').attr('class', 'bbtn btn-primary btn-smt');

        });
    });

    // Obtiene los valores de los textbox al dar click en el boton "Enviar"
    var divValue, values = '';

    function GetTextValue() {

            $('#respuesta_insertar_curso').empty();

        values = '';

        $('.input').each(function() {

            values=this.value;
            if (values!="") {
               insertar_cursos(values);
            }
         
        });

       
             
    }


     

        </script>

 </html>
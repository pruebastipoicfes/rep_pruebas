

(function() {

var curso_now;

    /**
     * Funcion que captura las variables pasados por GET
     * http://www.lawebdelprogramador.com/pagina.html?id=10&pos=3
     * Devuelve un array de clave=>valor
     */
    function getGET()
    {
        // capturamos la url
        var loc = document.location.href;
        // si existe el interrogante
        if(loc.indexOf('?')>0)
        {
            // cogemos la parte de la url que hay despues del interrogante
            var getString = loc.split('?')[1];
            // obtenemos un array con cada clave=valor
            var GET = getString.split('&');
            var get = {};
 
            // recorremos todo el array de valores
            for(var i = 0, l = GET.length; i < l; i++){
                var tmp = GET[i].split('=');
                get[tmp[0]] = unescape(decodeURI(tmp[1]));
            }
            return get;
        }
    }
 
    // window.onload = function()
    // {
        // Cogemos los valores pasados por get
        var valores=getGET();
        if(valores)
        {
            // hacemos un bucle para pasar por cada indice del array de valores
            for(var index in valores)
            {
                // document.write("<br>clave: "+index+" - valor: "+valores[index]);
                // alert("valor:"+valores[index]);
                curso_now=valores[index];
                if(curso_now=="no"){
                  window.location.href="resultados.php";
                }
            }
        }else{
            // no se ha recibido ningun parametro por GET
            // document.write("<br>No se ha recibido ningún parámetro");
        }
    // }










var prof=0;


// var curso_now="801";
  var curso_usuario_sesion;// VARIABLE PARA ALMACENAR EL CURSO DEL USUARIO QUE ACABA DE INICIAR SESION

     // var num_aleatorio_prueba='';
     var valor_1="801";
// curso_now = getParameterByName('Variable');

// var fre= getURLParameter("Variable");
// alert(fre);
var tree=[];
  //VARIABLE PARA SOLITAR EL JSON
    var xhReq;
    var jsonObject;
  ///////////////////////////////
  //ARREGLO PARA CANTIDAD DE PRUEBAS
  var arreglo_pruebas_cantidad_8=[["1"],["2"]];
    var arreglo_pruebas_cantidad_11=[["1"],["2"],["3"],["4"]];
  //////////////////////////////////////
var abc = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','Ñ','O','P','Q','R','S','T','U','V','W','X','Y','Z'];  //abecdario;

var tamanio_json;
var  array_json;
var arreglo_auxiliar_correctas=[];





function escoger_curso(n_curso_elegido){

var num_aleatorio_prueba;


  switch (n_curso_elegido)
        {
        case 6: //CURSOS 6
          alert("curso 6 ");
             // num_aleatorio_prueba= pedir_posicion_aleatoria(arreglo_pruebas_cantidad_8);

          break;
        case 7:

        alert("curso 7 ");
           // num_aleatorio_prueba= pedir_posicion_aleatoria(arreglo);
          break;  
        case 8:
        // alert("curso 8 ");
          var  pos_aleatorio= pedir_posicion_aleatoria(arreglo_pruebas_cantidad_8);
           num_aleatorio_prueba=arreglo_pruebas_cantidad_8[pos_aleatorio];
 

          break;
        case 9:
           // num_aleatorio_prueba= pedir_posicion_aleatoria(arreglo);
          break;
        case 10: //CURSOS 6
           // num_aleatorio_prueba= pedir_posicion_aleatoria(arreglo);
          break;
        case 11:

       var  pos_aleatorio= pedir_posicion_aleatoria(arreglo_pruebas_cantidad_11);
           num_aleatorio_prueba=arreglo_pruebas_cantidad_11[pos_aleatorio];

          break;     
        default: 
          break;
        
        }
        num_aleatorio_prueba=num_aleatorio_prueba.toString()+"+"+n_curso_elegido.toString();

   return num_aleatorio_prueba;
              

}


function cargar_pruebas(){





  $.ajax({
    type:'POST',
    url:'pedir_curso_usuario_actual.php',

}).done(function(respuesta){
// curso_now="801";
curso_now=respuesta;








});

//   $.ajax({
// type: "POST",
// url: "pedir_curso_usuario_actual.php",
// cache: false,
// success: function(data){

// curso_now=data;
// // alert()
// }

// });

  var curso_elegido;
curso_usuario_sesion=curso_now;
if (curso_usuario_sesion.length==4) {
    curso_elegido = curso_usuario_sesion.slice(0,2);
  // alert("curso_elegido"+curso_elegido);
} else if (curso_usuario_sesion.length==3){
    curso_elegido = curso_usuario_sesion.slice(0,1);
      // alert("curso_elegido"+curso_elegido);
}
   curso_elegido= parseInt(curso_elegido);
  var deve=escoger_curso(curso_elegido);

var num_prueba_y_curso= deve.split("+");

  var ress='json/archivo_'+num_prueba_y_curso[1]+'_'+num_prueba_y_curso[0]+'.json';
    xhReq = new XMLHttpRequest();
    xhReq.open("GET", ress, false); 
    xhReq.send(null); 
    jsonObject = JSON.parse(xhReq.responseText);

}



function llamar_json_y_remplzar(){


tamanio_json=(jsonObject.array_json_prueba_1.length);
array_json =jsonObject;

var nuevo_arr=[];
var nuevo_arr_correctas=[];
var arreglo_auxiliar=[];
var rescue_arreglo_auxiliar=[];

//RECOGER PRIMERO LAS RESPUESTAS CORRECTAS 
for (var i = 0; i < array_json.array_json_prueba_1.length; i++) 
{
    var arr_2=[];
  for (var j = 0; j < array_json.array_json_prueba_1[i].respuestas_correctas.length; j++) 
  {
      arr_2.push(array_json.array_json_prueba_1[i].respuestas_correctas[j]);
  }
  arreglo_auxiliar_correctas.push([arr_2]); /// !!!!!!!!!!!!!!!!!!!!!!!!
}
console.log("dedededede    arreglo_auxiliar_correctas=  "+arreglo_auxiliar_correctas);
//RECOGER LAS RESPUESTAS
for (var i = 0; i < array_json.array_json_prueba_1.length; i++) 
{

  for (var j = 0; j < array_json.array_json_prueba_1[i].respuestas.length; j++) 
  {
        console.log("parte= "+array_json.array_json_prueba_1[i].parte);

      for (var k = 0; k < array_json.array_json_prueba_1[i].respuestas[j].length; k++) 
        {
          arreglo_auxiliar.push( array_json.array_json_prueba_1[i].respuestas[j][k] );
          rescue_arreglo_auxiliar.push( array_json.array_json_prueba_1[i].respuestas[j][k]  );
        }

        var resp_correct_anterior= array_json.array_json_prueba_1[i].respuestas_correctas[j];
        nuevo_arr=tranformar_arreglo(arreglo_auxiliar);


        var b=true;
        var f = 0;
        while(b==true && f<nuevo_arr.length)
        {
          if (rescue_arreglo_auxiliar[resp_correct_anterior]==nuevo_arr[f]) 
          {
              array_json.array_json_prueba_1[i].respuestas_correctas[j]=f;
              b=false;
          }
         f=f+1;
        }

if (array_json.array_json_prueba_1[i].parte==2 ) {

  for (var h = 0; h < 5; h++) 
  {
      console.log("h= "+h+" --respuestas_correctas"+ array_json.array_json_prueba_1[i].respuestas_correctas);
    var indice_correcto= array_json.array_json_prueba_1[i].respuestas_correctas[(h+1)];
    indice_correcto=indice_correcto;
      console.log("1-- rescue_arreglo_auxiliar[indice_correcto]= "+rescue_arreglo_auxiliar[indice_correcto]+ "   indice= "+indice_correcto);
      console.log("h= "+h+" --rescue_arreglo_auxiliar"+rescue_arreglo_auxiliar);
    array_json.array_json_prueba_1[i].respuestas[j][h]=nuevo_arr;
          console.log("2h= "+h+" --rescue_arreglo_auxiliar"+rescue_arreglo_auxiliar);
  console.log("h= "+h+" --array_json.array_json_prueba_1[i].respuestas[j]"+ array_json.array_json_prueba_1[i].respuestas[h]);
  console.log("h= "+h+" --respuestas_correctas"+ array_json.array_json_prueba_1[i].respuestas_correctas);
      console.log("2-- rescue_arreglo_auxiliar[indice_correcto]= "+rescue_arreglo_auxiliar[indice_correcto]+ "   indice= "+indice_correcto);
console.log("nuevo_arr= "+nuevo_arr);
// var indice_correcto= ;
        var bo=true;
        var fo = 0;
        while(bo==true && fo<nuevo_arr.length)
        {
          if (rescue_arreglo_auxiliar[indice_correcto]==nuevo_arr[fo]) 
          {
              array_json.array_json_prueba_1[i].respuestas_correctas[(h+1)]=fo;
              bo=false;
          }
         fo=fo+1;
        }




  }

  // var arreglo_respuestas_parte_2=[];



}

          // Insertar uno por uno  Poner arreglo mezclado
      for (var d = 0; d < array_json.array_json_prueba_1[i].respuestas[j].length; d++) 
      {
        nuevo_arr[d]=abc[d].concat('.',nuevo_arr[d].slice(2));
        array_json.array_json_prueba_1[i].respuestas[j][d]= nuevo_arr[d];
      }

// console.log("final    ***  array_json.array_json_prueba_1[i].respuestas= "+array_json.array_json_prueba_1[i].respuestas);


        nuevo_arr.length=0;
        rescue_arreglo_auxiliar.length=0;


if (array_json.array_json_prueba_1[i].parte==2 ) {
  var length_j= array_json.array_json_prueba_1[i].respuestas.length;
j=(j+length_j);
console.log("entro j= "+j);
}


    }

        arreglo_auxiliar.length = 0;
  }
console.log("dedededede    arreglo_auxiliar_correctas=  "+arreglo_auxiliar_correctas);

}



function entrar(corr,con){


var dataString = 'correo='+corr+'&password='+con;


$.ajax({
type: "POST",
url: "ingresar.php",
data: dataString,
cache: false,
success: function(data){


  if(data=="no")
  {
    window.location.href="resultados.php";

  }else if(data!="no"){
    window.location.href = "prueba.php?Variable="+data;
    curso_usuario_sesion=data;
  }


}
});

}


//PARA INGRESAR
$('#login').click(function()
{
// function iniciar_sesion_usuario(){


var correo=$("#ing_correo").val();
var password=$("#ing_password").val();

 if(correo == ""){
      $("#ing_correo").focus();
    }
    if (password == ""  ){
      $("#ing_password").focus();
    }

var dataString = 'correo='+correo+'&password='+password;
if($.trim(correo).length>0 && $.trim(password).length>0)
{
    // alert("ing_correo= "+correo+" ing_password= "+password);
$.ajax({
type: "POST",
url: "ingresar.php",
data: dataString,
cache: false,
success: function(data){


  if(data=="no")
  {
    window.location.href="resultados.php";

  }else if(data!="no"){
    window.location.href = "prueba.php?Variable="+data;
    curso_usuario_sesion=data;
  }


}
});

}
return false;
});








cargar_pruebas();
llamar_json_y_remplzar();


function tranformar_arreglo(arreglo){
var arrelgo_mezclado = [];
var longitud_arreglo=arreglo.length;
  for (var i = 0; i < longitud_arreglo; i++) {
    var num= pedir_posicion_aleatoria(arreglo);
    arrelgo_mezclado.push(arreglo[num]);
    removeItemFromArr(arreglo,arreglo[num]); 
  }
    return arrelgo_mezclado;
}

function pedir_posicion_aleatoria(arr){
  var numero_participantes=arr.length;
  var numero=Math.floor(Math.random()*numero_participantes); //hallar posicion aleaotria 
return numero;
}

function removeItemFromArr( arr, item ) {
    var i = arr.indexOf( item );
    if ( i !== -1 ) {
        arr.splice( i, 1 );
    }
}


  var questionCounter = -1; //Tracks question number
  var selections = []; //Array containing user choices
  var quiz = $('#quiz'); //Quiz div object
  var regex = /(\d+)/g;
  var w='1';
  var terminar=false;

  crear_tabla_respuestas();


  // Display initial question
  displayNext();
  
  // Click handler for the 'next' button
  $('#next').on('click', function (e) {
    // alert("questionCounter"+questionCounter);
    e.preventDefault();
    if (questionCounter== -1) {
      // If no user selection, progress is stopped
   
      var x= validaForm();
     if (x==false) {

       // alert('Please make a selection!  X= '+x);
     } else if(x==true){
        // Suspend click listener during fade animation
        validar_datos();
        if(quiz.is(':animated')) {        
          return false;
        }
      questionCounter++;
      displayNext();
     }
    }
    else{
      // Suspend click listener during fade animation
        if(quiz.is(':animated')) {        
          return false;
        }

         questionCounter++;
         if(questionCounter>=7){
          // alert("sdsd");
          var mascara = document.getElementById('lamascara');
           mascara.style.display = "block";
         
    }else{
      displayNext();
    }

         
    }
  });

  
  // Click handler for the 'Start Over' button
  $('#start').on('click', function (e) {
    e.preventDefault();
    
    if(quiz.is(':animated')) {
      return false;
    }
     questionCounter = -1;
    // selections = [];
     displayNext();
     $('#start').hide();


  });
  
  // Animates buttons on hover
  $('.button').on('mouseenter', function () {
    $(this).addClass('active');
  });
  $('.button').on('mouseleave', function () {
    $(this).removeClass('active');
  });
  
  
  // Displays next requested element
 // Click handler for the 'Start Over' button
  $('#ejecutar_proceso').on('click', function (e) {
    e.preventDefault();
     $('#terminar').fadeOut();
      mascara.style.display = "none";
          questionCounter++;
          displayNext();
  });



 $('#cerrar_dialogo').on('click', function (e) {
    e.preventDefault();
       questionCounter=questionCounter-1;
           $('.contenido').fadeOut();
           $('.mascara').fadeOut();
           // displayNext();
  });

// MODAL VENTANA
var mascara = document.getElementById('lamascara');
var btn = document.getElementById("Btn");
var cerrar = document.getElementById("cerrar");

cerrar.onclick = function() {
 mascara.style.display = "none";
 questionCounter=questionCounter-1;
}
window.onclick = function(event) {
 if (event.target == mascara) {
 mascara.style.display = "none";
 }
}
// MODAL VENTANA

  function displayNext() {


    quiz.fadeOut(function() {
      $('#question').remove();
      // var largo=Object.keys(jsonObject).length;
      if(questionCounter < (tamanio_json+1) ) {
         var nextQuestion;
       
          switch (questionCounter)
          {
            case -1:
            nextQuestion=llenar_datos(questionCounter);
            // pedir_cursos("div_curso","curso_seleccionado()");
            // pedir_profesores();
            $('#respuestas').css({'display':'none'});
            $('.contenedor_3').css({'width':'97%'});
            $('.contenedor_3').css({'height':'95%'});
            document.getElementById("next").innerHTML = "Comenzar<br> prueba";
              break;
             case 0:
             $('.contenedor_3').css({'width':'1013px'});
             $('#respuestas').css({'display':'inline-block'});
   document.getElementById("next").innerHTML = "Next";
             nextQuestion = generar_pregunta_tipo_1(questionCounter);
             carga();
               break;
             case 1:
             nextQuestion = generar_pregunta_tipo_2(questionCounter);
               break;
             case 2:
             nextQuestion =generar_pregunta_tipo_3(questionCounter);

              break;
             case 3: 
             case 4:
             case 5:
             case 6:
              
              nextQuestion=generar_pregunta_tipo_4(questionCounter);
                 break;
             case 7:
  
                 nextQuestion=validar_terminacion();
                break;
              // case 8:
              //        alert(questionCounter);
              //   alert("entro");
              //   nextQuestion=displayScore();
              //   break;
             default: 
             break;
        
          }
          quiz.append(nextQuestion).fadeIn();
        iluminar(questionCounter);
        
        // Controls display of 'prev' button
        if(questionCounter === 1){
          // $('#prev').show();
            $('#next').show();
        } else if(questionCounter === -1){
          
          // $('#prev').hide();
          $('#next').show();
        } else if(questionCounter === 0)
        {

          // $('#prev').hide();
          $('#next').show();
        } else if(questionCounter === 7)
        {
         
          // $('#prev').hide();
          $('#next').hide();
        }
      }else {
        // alert("entro"+questionCounter);
        
        var scoreElem = displayScore();
         quiz.append(scoreElem).fadeIn();

        $('#next').hide();
        // $('#prev').hide();
        // $('#start').show();


      }
    });
  }
  



  // VALIDAR TERMINACION
  function validar_terminacion(){
   var qElement = $('<div>', {
      id: 'question',
      class: 'pregunta' 
    });
  
document.getElementById("terminar").style.display = "inline-block";

return qElement;

  }

  //////////////////////
  //función que sirve para cerrar el cuadro de dialogo
    

  // Computes score and returns a paragraph element to be displayed
  function displayScore() {
     // document.getElementById("terminar").style.display = "none";
     $('#respuestas').css({'display':'none'});
      $('.contenedor_3').css({'width':'97%'});
      $('.contenedor_3').css({'height':'95%'});

  var qElement = $('<div>', {
      id: 'question',
      class: 'puntaje_2' 
    });
  
  var resp= combrobar_respuestas();
   
    // var header = $('<br><h4 class="">Su calificación es:  '+resp[0]+' </h4><br> y su calificación icfes es: '+resp[1]+'<br>');
     var header = $('<br><h3 class=""> Su calicación académica es: '+resp[0]+' </h3><br><h3><br>y su calicación parámetro TIPO ICFES es:'+resp[1]+'</h3> <br>');
    var div = $('<div class="btn btn-info"> <a href="resultados.php">Ir a mis resultados</a></div>');
    qElement.append(header);
    qElement.append(div);

    guardar_resultado(resp);

    return qElement;
  }



// CALCULAR TIEMPO

            function padNmb(nStr, nLen) {
                var sRes = String(nStr);
                var sCeros = "0000000000";
                return sCeros.substr(0, nLen - sRes.length) + sRes;
            }
 
            function stringToSeconds(tiempo) {
                var sep1 = tiempo.indexOf(":");
                var sep2 = tiempo.lastIndexOf(":");
                var hor = tiempo.substr(0, sep1);
                var min = tiempo.substr(sep1 + 1, sep2 - sep1 - 1);
                var sec = tiempo.substr(sep2 + 1);
                return (Number(sec) + (Number(min) * 60) + (Number(hor) * 3600));
            }
 
            function secondsToTime(secs) {
                var hor = Math.floor(secs / 3600);
                var min = Math.floor((secs - (hor * 3600)) / 60);
                var sec = secs - (hor * 3600) - (min * 60);
                return padNmb(hor, 2) + ":" + padNmb(min, 2) + ":" + padNmb(sec, 2);
            }
 
            function substractTimes(t1, t2) {
                var secs1 = stringToSeconds(t1);
                var secs2 = stringToSeconds(t2);
                var secsDif = secs1 + secs2;
                return secondsToTime(secsDif);
            }
 
            function calcT3(t1,t2) {

                    // t3.value = substractTimes(t1.value, t2.value);
                    return substractTimes(t1, t2);
            }
///////////////////

// -------------- funcion para restar tiempo
function restarHoras(t_inicio,t_fin) {

  // inicio = document.getElementById("inicio").value;
  // fin = document.getElementById("fin").value;
    inicio = t_inicio;
  fin = t_fin;
  
  inicioMinutos = parseInt(inicio.substr(3,2));
  inicioHoras = parseInt(inicio.substr(0,2));
  
  finMinutos = parseInt(fin.substr(3,2));
  finHoras = parseInt(fin.substr(0,2));

  transcurridoMinutos = finMinutos - inicioMinutos;
  transcurridoHoras = finHoras - inicioHoras;
  
  if (transcurridoMinutos < 0) {
    transcurridoHoras--;
    transcurridoMinutos = 60 + transcurridoMinutos;
  }
  
  horas = transcurridoHoras.toString();
  minutos = transcurridoMinutos.toString();
  
  if (horas.length < 2) {
    horas = "0"+horas;
  }
  
  if (horas.length < 2) {
    horas = "0"+horas;
  }

  if (minutos.length==1) {
    minutos='0'+minutos;
  }
    var resultado_tiempo="00:"+horas+":"+minutos;
  // document.getElementById("resta").value = 
 return resultado_tiempo;
}

// --------------- fin funcion

// GUARDAR RESULTADO

function guardar_resultado(resultado){

  var cc="00";
  var p=":";
  var s = $("#segundos").text();
  var m = $("#minutos").text();
  console.log("s= "+s+"   m= "+m);

s=s.toString();
m=m.toString();
// alert("resultado= "+resultado[0]);
var time="";
time=time.concat(m,p,s,p,cc);
var time_total="60:00:00";
contador_m_inicial=contador_m_inicial+':00';
var resultado_tiempo_resta=restarHoras(time.slice(0,5),contador_m_inicial);
var dataString='resultado='+resultado[0]+'&resultado_icfes='+resultado[1]+'&time='+resultado_tiempo_resta;

$.ajax({

type: "POST",
url: "registro_resultado.php",
data: dataString,
cache: false,
// beforeSend: function(){ $("#login").val('Connecting...');},
success: function(data){

if(data=="si")
{
  // alert("si inserto");
}

}

});

}


//GENERAR TABLA DE RESPUESTAS
function crear_tabla_respuestas(){
  for (var i = 0; i < jsonObject.array_json_prueba_1.length; i++) {

    for (var j = 0; j < array_json.array_json_prueba_1[i].respuestas.length; j++) {

          var tr = $('<tr class="'+array_json.array_json_prueba_1[i].parte+'">');
          var fila='';
          var num_pregunta=array_json.array_json_prueba_1[i].preguntas[j].slice(0,3);
          num_pregunta=num_pregunta.match(regex);
          tr.append('<td>'+num_pregunta+'</td>');

      for (var k = 0; k < array_json.array_json_prueba_1[i].respuestas[j].length; k++) {
 
            // fila=' <td class="forum"> <input type="radio" name="tabla_respuesta_'+num_pregunta+'" value="'+array_json[i].respuestas[j][k].slice(0,1)+'" ></td>';
            fila=' <td class="forum"> <input type="radio" name="tabla_respuesta_'+num_pregunta+'" value="'+k+'" ></td>';


            // var fe=array_json[i].respuestas[j][k];
            // console.log(fe);
            tr.append(fila);

        }

     $('#tabla_respuestas_body').append(tr);
    }
  }
}
////////////////////////////




//GENERAR PREGUNTA DE TIPO 1 CON IMAGEN

function generar_pregunta_tipo_1(ind){

    var qElement = $('<div>', {
      id: 'question',
      class: 'pregunta' 
    });
  
    var header = $('<br><div class="enunciado_general">'+array_json.array_json_prueba_1[ind].enunciado_general+':</div>');

     qElement.append(header);

  for (var i = 0; i < array_json.array_json_prueba_1[ind].preguntas.length; i++) {
    var imagen='';
    var response='';
     imagen+='<div class="pregunta_1" >'+array_json.array_json_prueba_1[ind].preguntas[i]+'<img style="width:200px;" src="'+array_json.array_json_prueba_1[ind].imagen[i]+'" alt=""></div>';
     
    for (var j = 0; j < array_json.array_json_prueba_1[ind].respuestas[i].length; j++) {
      var radioList = $('<ul>');
      response +='<li>'+array_json.array_json_prueba_1[ind].respuestas[i][j]+'</li>';  
     }
      var div = $('<div>', {
      class: 'pregunta_2' 
    }); 




         var div_div = $('<div>', {
      class: 'div_div' 
    }); 

       // radioList.append(response);
       // div.append(radioList);
       // div_div.append(div);
       // div_div.append(pregunta);
       // qElement.append(div_div);


       radioList.append(response);
       div.append(radioList);
       div_div.append(div);
       div_div.append(imagen);
       qElement.append(div_div);
     }
      return qElement;
}

function generar_pregunta_tipo_2(ind){

   var qElement = $('<div>', {
      id: 'question',
      class: 'pregunta' 
    });
    var header = $('<br><div class="enunciado_general">'+array_json.array_json_prueba_1[ind].enunciado_general+':</div>');
   
    qElement.append(header);
    pregunta='';

  for (var i = 0; i < array_json.array_json_prueba_1[ind].preguntas.length; i++) 
    {
     pregunta+='<div class="pregunta_1_parte_2" >'+array_json.array_json_prueba_1[ind].preguntas[i]+'</div>';
     
     }
       qElement.append(pregunta);
       qElement.append('<br>');
       var response='';

  for (var j = 0; j < array_json.array_json_prueba_1[ind].respuestas[0].length; j++) {

      var radioList = $('<div>');
      response +='<div class="caja">'+array_json.array_json_prueba_1[ind].respuestas[0][j]+'</div>';  
     
     }
      radioList.append(response);
      qElement.append(radioList);
      return qElement;
}


function generar_pregunta_tipo_3(ind){

     var qElement = $('<div>', {
      id: 'question',
      class: 'pregunta' 
    });
    var header = $('<br><div class="enunciado_general">'+array_json.array_json_prueba_1[ind].enunciado_general+':</div>');
    qElement.append(header);
    
      for (var i = 0; i < array_json.array_json_prueba_1[ind].preguntas.length; i++) {
    var pregunta='';
    var response='';
     pregunta+='<div class="pregunta_1" >'+array_json.array_json_prueba_1[ind].preguntas[i]+'</div>';
     
    for (var j = 0; j < array_json.array_json_prueba_1[ind].respuestas[i].length; j++) {
      var radioList = $('<ul>');
      response +='<li>'+array_json.array_json_prueba_1[ind].respuestas[i][j]+'</li>';  
     }

      var div = $('<div>', {
      class: 'pregunta_2' 
    }); 


         var div_div = $('<div>', {
      class: 'div_div' 
    }); 

       radioList.append(response);
       div.append(radioList);
       div_div.append(div);
       div_div.append(pregunta);
       qElement.append(div_div);
     
     }


      return qElement;
}


function generar_pregunta_tipo_4(ind){

 var qElement = $('<div>', {
      id: 'question',
      class: 'pregunta' 
    });
    var header = $('<br><div class="enunciado_general">'+array_json.array_json_prueba_1[ind].enunciado_general+'</div>');
    qElement.append(header);

    var div_div = $('<div>', {
      class: 'div_div_2' 
    }); 
         var div_general_right = $('<div>', {
      class: 'div_general_right' 
    }); 

 var texto='';
 texto +='<div class="div_texto"> <h3 class="titulo">'+array_json.array_json_prueba_1[ind].titulo+'</h3>'
 texto +='<div id="texto">'+array_json.array_json_prueba_1[ind].texto+'</div></div>';



  var resp='<h3 class="titulo">Respuestas</h3>';
  div_general_right.append(resp); 
for (var i = 0; i < array_json.array_json_prueba_1[ind].preguntas.length; i++) {
  var div=$('<div>',{
  class: 'respuesta_line'
});
  
  var pregunta='';
   pregunta+='<br><div style="float:left; color:blue; ">'+array_json.array_json_prueba_1[ind].preguntas[i]+'.'+'</div><br>';

  for (var j = 0; j < array_json.array_json_prueba_1[ind].respuestas[i].length; j++) {
       pregunta+='<div class="item_horizontal"> '+array_json.array_json_prueba_1[ind].respuestas[i][j]+'</div><br>';
  }

 div.append(pregunta);

div_general_right.append(div);

}

div_div.append(texto);
div_div.append(div_general_right);
qElement.append(div_div);
 return qElement;

}



function redondeo(numero, decimales)
{
var flotante = parseFloat(numero);
var resultado = Math.round(flotante*Math.pow(10,decimales))/Math.pow(10,decimales);
return resultado;
}


  function combrobar_respuestas(){

var resultadosPrueba=[];
var respuestas_usuario;
 var cont=1;
 var percent=parseFloat(0);
 var percent_2=parseFloat(0);
 var respuestas_ok= parseFloat(0);

 // Tomar respuestas correctas
for (var i = 0; i < array_json.array_json_prueba_1.length; i++) {
  for (var j = 0; j < array_json.array_json_prueba_1[i].respuestas_correctas.length; j++) {

        var respuestas_usuario=$('input[name="tabla_respuesta_'+cont+'"]:checked').val();
        console.log("cont= "+cont+"     respuestas_correctas= "+array_json.array_json_prueba_1[i].respuestas_correctas[j]+"  -----  respuestas_usuario= "+respuestas_usuario); 
        if (respuestas_usuario==array_json.array_json_prueba_1[i].respuestas_correctas[j]) {
          respuestas_ok=respuestas_ok+1;
        }
         cont=cont+1;
  }
}
cont=cont-1;
percent=( (respuestas_ok*5)/cont );
percent_2=( (respuestas_ok*100)/cont );
console.log("RESPUESTAS percent =  "+percent);
console.log("RESPUESTAS percent_2 =  "+percent_2);

percent=redondeo(percent,2);
percent_2=redondeo(percent_2,2);


resultadosPrueba.push([percent]);
resultadosPrueba.push([percent_2]);

console.log("RESPUESTAS resultadosPrueba =  "+resultadosPrueba);
 return resultadosPrueba;

}

//////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////



function llenar_datos(ind){

  // alert("<?php echo $hola;?>");
 var qElement = $('<div>', {
      id: 'question',
      class: 'pregunta' 
    });
 qElement.append('<div class="imagen_ini"><img style="" src="https://www.pruebastipoicfes.com/img/ima_comenzar.png" alt=""></div>');


return qElement;
} 



function validaForm(){
    // Campos de texto
    if($("#colegio").val() == ""){
        alert("El campo colegio no puede estar vacío.");
        $("#colegio").focus();       // Esta función coloca el foco de escritura del usuario en el campo Nombre directamente.
        return false;
    }
 
     if($("#curso").val() == "Seleccione su curso"){
        alert("Por favor, seleccione un curso.");
        $("#curso").focus();
        return false;
    }
     if($("#fecha").val() == ""){
        alert("El campo fecha no puede estar vacío.");
        $("#fecha").focus();
        return false;
    }

     if($("#profesor").val() == "Seleccione su profesor"){
        alert("Por favor, seleccione un profesor.");
        $("#profesor").focus();
        return false;
    }


    return true; // Si todo está correcto
}


function validar_datos(){



var colegio=$("#colegio").val();
var curso=$("#curso").val();
var fecha=$("#fecha").val();
var profesor=$("#profesor").val();


var dataString='colegio='+colegio+'&curso='+curso+'&fecha='+fecha+'&profesor='+profesor;


$.ajax({
type: "POST",
url: "registro.php",
data: dataString,
cache: false,
// beforeSend: function(){ $("#login").val('Connecting...');},
success: function(data){

if(data)
{

// $("body").load("home.php").hide().fadeIn(1500).delay(6000);
//or
// window.location.href = "prueba.php";

}
else
{
//Shake animation effect.
// $('#box').shake();
// $("#login").val('Login');
// $("#error").html("<span style='color:#cc0000'>Error:</span> correo o contraseña invalido. ");


}
}
});

}

// ILUMINAR LAS FILAS QUE DEBE RESPONDER

function iluminar(ind){

//Poner en blanco el anterior
// $(w).toggleClass('forum_hover_2');
var res=w;
ind=ind+1;
w='.'+ind;

// Bajar transparencia y deshabilitar todos los inputs
$("tr input[type=radio]").attr('disabled', true);
$("tr input[type=radio]").css('opacity', 0.4);
$(res).toggleClass('forum_hover');
// $(w).toggleClass('forum_hover_2');
// $(w).removeClass("forum_hover");
// $(w).addClass("forum_hover_2");

// Activar color y habilitar los inputs actuales
$(w+' input[type=radio]').css('opacity', 1.0);
$(w+' input[type=radio]').attr('disabled', false);
$(w).toggleClass('forum_hover');
// $(w).focus();

 // $(w).hover(function(){$(this).toggleClass('forum_hover');});

// $(".5").focus();
}

function llenar_select_profesor(datos){
var div='';
  div+='<label for="profesor" class="col-sm-2 control-label">Profesor</label> <div class="col-sm-10"> <select class="form-control" name="profesor" id="profesor" onchange="profesor_seleccionado();" required>';
  div+='<option>Seleccione su profesor</option>';
for (var i = 0; i < datos.length; i++) {
  div+='<option value="'+datos[i].id_profesor+'">'+datos[i].nombre+' '+datos[i].apellido+'</option>';
}
div+='</select></div>';
$('#div_profesor').append(div);
}

function pedir_profesores(){

  $.ajax({
    type:'POST',
    url:'retornar_profesores.php'
}).done(function(respuesta){
var datos =JSON.parse(respuesta);
llenar_select_profesor(datos);
});

}




// time
  var cronometro;

   var contador_s =0;
   var contador_m =60;
   // contador_m_inicial=contador_m_inicial.toString(contador_m_inicial);
   // con
   var contador_m_inicial=contador_m;
   var tiempo_min=contador_m;
   var tiempo_seg=contador_s;


  function detenerse()
  {
    clearInterval(cronometro);
  
    questionCounter=(array_json.length+1);
    displayNext();

  }

function carga()
  {
 

    s = document.getElementById("segundos");
    m = document.getElementById("minutos");

// Empezar
m.innerHTML = contador_m;
s.innerHTML = contador_s;
// Empezar
    cronometro = setInterval(
      function(){
        if(contador_s==0)
        {
          contador_s=60;
          contador_m--;
          m.innerHTML = contador_m;

          if(contador_m==0)
          {
            // console.log("entro contador_m "+contador_m);
            contador_m=60;

          }
        }
  contador_s--;
  s.innerHTML = contador_s;

if(s.innerHTML.length==1){
        var cero="0";
        var segunda_cifra= s.innerHTML;
        segunda_cifra=segunda_cifra.toString();
        var seg="";
        seg = seg.concat(cero,segunda_cifra);
        s.innerHTML = seg;   //Imprimir   
    }

if(m.innerHTML.length==1){
        var m_cero="0";
        var m_segunda_cifra = m.innerHTML;
        m_segunda_cifra=m_segunda_cifra.toString();
        var min="";
        min = min.concat(m_cero,m_segunda_cifra);
        m.innerHTML = min;   //Imprimir   
      }
      if (m.innerHTML=="00" && s.innerHTML=="00") {
        detenerse();
        // #de5b5b
      }
      if(m.innerHTML=="01" && s.innerHTML=="00"){
               $('#time').css({'background':'#de5b5b'});
      }
    }
  ,1000);
}
// time








})();




function llenar_select_cursos(datos,div_fill,onchange){
    $('#'+div_fill).empty();
var div='';
div+='<label for="curso" class="col-sm-2 control-label">Curso</label> <div class="col-sm-10"> <select class="form-control" name="curso" id="curso" onchange="'+onchange+'"  required>';
div+='<option>Seleccione su curso</option>';

// div+='<option><input type="text" id="buscar"></option>';

for (var i = 0; i <datos.length; i++) {
div+='<option value="'+datos[i].id_curso+'">'+datos[i].nombre_curso+'</option>';
}
  div+='</select></div>';  

$('#'+div_fill).append(div);
}

// fffffffffffffffffffffffffffffffffffffff

function pedir_cursos(div_fill,onchange){

    $.ajax({
    type: "POST",
    url: 'retornar_cursos_panel_profesor.php'
  }).done(function(respuesta){
var datos = JSON.parse(respuesta);
llenar_select_cursos(datos,div_fill,onchange);


});

  
}


function llenar_select_colegio_ciudad(){


}
// funcion para pedir colegio y ciudad
function pedir_colegio_ciudad(){

  var buscar = $('#colegio_ciudad_buscar').text();




}

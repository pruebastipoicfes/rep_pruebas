
 var array_json = [
   {
    parte: 1,
    enunciado_general:"¿Dónde puede ver estos avisos? En las preguntas 1-5 marque A, B ò C en la tabla de respuestas",
    preguntas:[
    "1.",
    "2.",
    "3.",
    "4.",
    "5."
    ],
    respuestas:[
    /*1*/["A. In the hospital","B. In the supermarket","C. In the aquarium"],
    /*2*/["A. On a newspaper","B. On TV","C. In a web page"],
    /*3*/["A. In a the playground","B. In the cinema","C. In the classroom"],
    /*4*/["A. At the airport","B.On the street","C. In a gym"],
    /*5*/["A. On the floor","B. On the roof","C. On a door"]
    ],
    respuestas_correctas:[1,2,1,0,2],
    imagen:[
    "http://www.pruebastipoicfes.com/img/p1_1.PNG",
    "http://www.pruebastipoicfes.com/img/p1_2.PNG",
    "http://www.pruebastipoicfes.com/img/p1_3.PNG",
    "http://www.pruebastipoicfes.com/img/p1_4.PNG",
    "http://www.pruebastipoicfes.com/img/p1_5.PNG"
    ]

   },

 {
    parte: 2,
    enunciado_general: "¿Cuál palabra (A-H) concuerda con la descripción de las frases deabajo (6-10)? En las preguntas 6-10 marque A a H.",
   
    preguntas: ["6. Something you need to make a sandwich.",
    "7. Place where people go to pray",
    "8. Small white or brown grains that you boil in water until they become soft enough to eat",
    "9. The best thing to drink when you are thirsty.",
    "10. Place where monkeys live."],

    respuestas: [
    ["A. Jungles","B. Rice","C. Factory","D. Water","E. Meat","F. Street","G. Bread","H. Church"],
    ["A. Jungle","B. Rice","C. Factory","D. Water","E. Meat","F. Street","G. Bread","H. Church"],
    ["A. Jungle","B. Rice","C. Factory","D. Water","E. Meat","F. Street","G. Bread","H. Church"],
    ["A. Jungle","B. Rice","C. Factory","D. Water","E. Meat","F. Street","G. Bread","H. Church"],
    ["A. Jungle","B. Rice","C. Factory","D. Water","E. Meat","F. Street","G. Bread","H. Church"]],

    respuestas_correctas:[6,7,1,3,0]
  

  },

  {
    parte: 3,
    enunciado_general:"Complete las conversaciones. En las preguntas 11 a 15, marque A, B ò C en su hoja de respuestas",
    preguntas:[
    "11. Where did you go last holiday?",
    "12. Why not?",
    "13. Did you enjoy the party?",
    "14. What do you do in your free time?",
    "15. Why are you learning English?"
    ],
    respuestas:[
    /*11*/["A. I am sorry","B. I went to New York.","C. I bought some gifts"],
    /*12*/["A. Yes, I did","B. Just a minute","C. Because it was boring"],
    /*13*/["A. It was wonderful.", "B. I don´t know","C. I can help you"],
    /*14*/["A. At home.","B. I went there in December","C. I usually go shopping"],
    /*15*/["A. Because I am sick","B. Because I need it for my job.", "C. I am fine, thanks."]
    ],
     respuestas_correctas:[1,2,0,2,1]
  },
  {
    parte:4,
    enunciado_general:"Lea el texto de la siguiente parte. Escoja la palabra (A, B, o C) para cada espacio. En las preguntas 16-23 marque A, B ò C en su hoja de respuestas",
    titulo:"Artículo",
    texto:"My name is Simon, but everybody calls me Simmie. I’m eleven years old. I (16)__________ born in Norwich, in England, on December 3rd, but I live with my family near Edinburgh, the capital city of Scotland. My parents (17) ___________ the countryside, so two years (18) ________ we moved to Gifford, a beautiful village in East Lothian, not far from Edinburgh. As my parents work in Edinburgh, they have to drive into the city every day, but they don’t mind. We live in a large wooden house. As we go in through the front door, there is a hall and a big living room on the left with a staircase that leads up to the first floor. On the right, there is a study (19) _________ my father works in the evening. Next to the study there is the family room. That’s our favorite place in the house. That is where we have our meals, talk to each other, and watch TV. In the winter, we always light up the fireplace to keep us warm. The kitchen is next to the family room. We don’t (20) ________ a bathroom downstairs, but there’s a toilet. Upstairs, there are three bedrooms. My parents’ bedroom is the (21) _________ one. It has a private bathroom and a window that looks over the garden. My younger brother’s bedroom is next (22) _________ my parents’ and mine is right in front (23) _______the staircase, next to the other bathroom. We don’t have a guest room, so when my grandparents come over, I sleep in my brother’s room.",
    preguntas:[
    "16",
    "17",
    "18",
    "19",
    "20",
    "21",
    "22",
    "23"],
    respuestas:[
    /*16*/["a) were","b) was ","c) be"],
    /*17*/["a) loves","b) loving ","c) love "],
    /*18*/["a) last ","b) ago ","c) on "],
    /*19*/["a) where ","b) what ","c) who "],
    /*20*/["a) go","b) make","c) have "],
    /*21*/["a) big ","b) biggest ","c) big "],
    /*22*/["a) down ","b) up ","c) to "],
    /*23*/["a) to ","b) of ","c) up"]
    ],
    respuestas_correctas:[1,2,1,0,2,1,2,1]

  },
  {
    parte:5,
    enunciado_general:"Lea el artículo y luego responda a las preguntas.En las preguntas 24 a 28 marque A, B ò C en su hoja de respuestas.",
    titulo:"Artículo",
    texto:"Hi! My name is Nicholas. I am 12 years old. I am from Liverpool and I live there with my father, my mother and my siblings – Sean, who is 10 years old, and Diana, our little Princess, who’s 4. Our day starts at 7 o’clock, when the alarm clock rings. Everybody gets up and gets ready to leave home at 7:45 o’clock. I usually take a shower in the evening, so I just have to wash my face, brush my teeth, and put on my school uniform. We all have breakfast at 7:30. I like to eat cereal with milk, and French toast or waffles. We all love pancakes and English muffins with cheese, but we only have those at the weekend. After breakfast, Sean and I catch the bus to school. Classes begin at 8 sharp. Mom and Dad drive to work after leaving Diana at the kindergarten. My dad is a pediatrician and my mum is a nurse. They both work at the local hospital. When school finishes, at 3 o’clock, Sean and I take the bus home. We have a glass of milk and a toast and then we do our homework. On Wednesdays we go home later. We have extracurricular activities. Sean goes to the Internet Club and I go to the Music Club. I want to be a famous musician. That’s why at the weekend I go to L.I.P.A – Liverpool Institute for Performing Arts. The Institute was co-founded by Sir Paul McCartney and is the best performing arts school in Britain. I have drama, singing and dancing lessons, one hour dedicated to each discipline. I’ve always loved music and I started playing the piano when I was 4 years old. At 6 I played several Christmas songs at a school party. I’ve also learned to play the drums and the guitar. When I grow up, I want to take a music degree at L.I.P.A. I must study hard to get high grades because they only have 35 places available each year. One of those places has to be for me!",
    preguntas:[
    "24. Nicholas is ……….",
    "25. Nicholas and Sean go to school...",
    "26. They ……….… after school.",
    "27. Nicholas loves……..",
    "28. There are …….… available at L.IPA."],
   
    respuestas:[
    /*24*/["a) American","b) English","c) Scottish"],
    /*25*/["a) by car","b) by bus","c) on foot"],
    /*26*/["a) go to the gym ","b) watch TV","c) have a snack"],
    /*27*/["a) music"," b) school"," c) art"],
    /*28*/["a) many places","b) few places","c) no places"]
    ],
    respuestas_correctas:[1,1,2,0,1]
  },
  {
    parte:6,
    enunciado_general:"Lea el siguiente texto.En las preguntas 29 a 33, marque A, B, C ò D en su hoja de respuestas.",
    titulo:"SMALL TALK ISN´T TOO SMALL",
    texto:"Small talk may not be about serous issues; nevertheless into the subject have concluded that it´s important. That´s because small talk keeps us connected to one another and can lead to bigger things, such as a job or a new friendship. Yet people who find themselves alone with another person often don´t know what to say. Here are a few tips to help you start a conversation, and to keep the conversational ball rolling: Contacto para solicitud de Pruebas Saber o material bilingüe : hispanaeditoracotizaciones @gmail.com 6 PRUEBA:8.9. Start with the obvious. If you have something in common with another person (your job, hobbies, a person you both know, etc.), begin with that. If you don´t know the person, it´s always acceptable to bring up a neutral topic such as the weather or a recent news event. It isn´t necessary to be clear – all that´s required is to show interest in the other person and to be willing to talk. Compliment where appropriate. If the other person has done something you like or is wearing something attractive, it´s always appropriate to compliment. But avoid talking about the specifics of a person´s physical appearance (people can´t usually change how they look) and keep your compliments short and to the point (“What a great tie” or “You´re great tonight”) and continue with another topic. Talk about yourself – then return to your partner. It´s perfectly OK to talk about your own interest for a while, but keep your conversation from becoming a monolog. It´s only polite, for example, that after talking about your children, you turn the conversation back to your partner by asking about his or her children.",
    preguntas:[
    "29. according to the article, the main function of small talk is to __________",
    "30. “Start with the obvious” means that you should talk about things that you _______",
    "31. you need to be careful when complimenting someone because most people _______",
    "32. you should avoid monologs because other people __________",
    "33. the expression “keep your compliments short and to the point” means __________"],

    respuestas:[
    /*29*/["a. show our own importance","b. get valuable information","c. relate to other people","d. talk about major issues"],
    /*30*/["a. Have in common","b. enjoy doing","c. want to understand","d. know everything about"],
    /*31*/["a. don´t like compliments","b. can´t change how they look","c. don´t dress very well","d. haven´t done anything interesting"],
    /*32*/["a. have no interest in what you say","b. already know a lot about you","c. like to talk themselves, too","d. prefer to discuss neutral subjects"],
    /*33*/["a. you should extend your comments","b. you should make as many comments as possible","c. you should make good comments only to short people","d. your comments should be clear and short"]
    ],
     respuestas_correctas:[2,0,1,2,3]
  },
  {
    parte:7,
    enunciado_general:"Responda las preguntas 34 a 40 de acuerdo con el siguiente texto.",
    titulo:"Artículo",
    texto:"The British spend their free time in different ways. People generally use(34) _______ to relax, but many people also do voluntary work, especially for charities. A lot of free time is spent in the home, (35) ______ the most popular leisure activity is watching television, the average viewing time being 25 hours a week. People often record programmes so that they can watch(36) _________ later. Reading is also a favourite way of spending leisure time. The British spend a lot of time reading newspapers and magazines. In the summer gardening (37) _________ popular, and in winter it is often replaced by ‘do-it-yourself’, when people spend time improving or repairing their homes. Many people have pets to look after. Taking the dog for a walk is a regular routine. Some leisure activities are mostly or entirely social. Inviting friends for a drink or a meal at home is the most usual one. Sometimes people join friends for a drink in a pub, or have dinner in a restaurant. A visit to a pub often includes a game, for example billiards or darts. Contacto para solicitud de Pruebas Saber o material bilingüe : hispanaeditoracotizaciones @gmail.com 8 PRUEBA:8.9. The extra time available(38) ________ weekends means that some leisure activities, many of them to do with sport, normally take place only then. Traditional spectator sports include football, cricket, horse racing, motor racing and motor cycle racing. Popular forms of exercise are swimming, tennis, ice-skating or rollerskating, cycling, climbing, and hill or country walking. Families often (39) _________ a ’day out’ at the weekend, especially in summer, with a visit to a local event such as a festival, fair or show. Young people especially(40) __________ to clubs and discos, while people of all ages go to the theatre, the cinema, art exhibitions and concerts.",
    preguntas:[
    "34",
    "35",
    "36",
    "37",
    "38",
    "39",
    "40"
    ],
    respuestas:[
    /*34*/["a. he","b. them","c. the","d. it"],
    /*35*/["a. who","b. where ","c. how","d. what"],
    /*36*/["a. a","b. their","c. them","d. this"],
    /*37*/["a. are","b. goes","c. drink","d. is"],
    /*38*/["a. at","b. in","c. the","d. be"],
    /*39*/["a. has","b. have","c. make","d. go"],
    /*40*/["a. are","b. drink","c. go","d. goes"]
    
    ],
    respuestas_correctas:[3,1,2,3,0,1,2]
  }
];




